document.querySelector('[data-print-guide]')?.addEventListener('click', () => window.print());

import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {fonts} from '../scripts/font-catalog.mjs';
const base='http://127.0.0.1:4173';
const cases=[['/',200,'text/html'],['/bangla-fonts/',200,'text/html'],['/assets/js/main.js',200,'javascript'],['/assets/js/font-library.js',200,'javascript'],['/assets/js/bijoy-engine.js',200,'javascript'],['/assets/fonts/hind-siliguri.zip',200,'application/zip'],['/assets/fonts/NotoSansBengali-Regular.ttf',200,'font/ttf'],['/guides/install-bangla-font/',200,'text/html'],['/sitemap.xml',200,'application/xml'],['/robots.txt',200,'text/plain'],['/llms.txt',200,'text/plain'],['/assets/aistudio/Pages_3ecfd76a.csv',404,'text/html'],['/not-a-real-page/',404,'text/html']];
cases.push(['/office-letters-notices/school-closure-notice/',200,'text/html'],['/academic-applications/hostel-leaving-application/',200,'text/html'],...['planned-closure','emergency-closure','reopening-notice','permanent-departure','guardian-request'].map(id=>['/assets/downloads/'+id+'.txt',200,'text/plain']));
cases.push(['/academic-applications/admission-with-transfer-certificate/',200,'text/html'],['/office-letters-notices/experience-certificate-format/',200,'text/html'],...['tc-school-admission','tc-college-admission'].map(id=>['/assets/downloads/'+id+'.txt',200,'text/plain']));
cases.push(['/office-letters-notices/joining-letter-format/',200,'text/html'],['/office-letters-notices/employment-verification-letter/',200,'text/html'],...['joining-office-bangla','joining-teacher-bangla','joining-office-english','employment-current-bangla','employment-current-english'].map(id=>['/assets/downloads/'+id+'.txt',200,'text/plain']));
cases.push(...['handover-letter-format','internship-certificate-format'].map(slug=>['/office-letters-notices/'+slug+'/',200,'text/html']),...['handover-bangla','handover-english','internship-certificate-bangla','internship-certificate-english','internship-certificate-request'].map(id=>['/assets/downloads/'+id+'.txt',200,'text/plain']));
cases.push(['/professional-emails/job-application-email-sample/',200,'text/html'],['/office-letters-notices/salary-certificate-format/',200,'text/html'],...['job-email-fresher','job-email-experienced','job-email-internship','salary-certificate-bangla','salary-certificate-english','salary-certificate-request'].map(id=>['/assets/downloads/'+id+'.txt',200,'text/plain']),...['salary-certificate-bangla','salary-certificate-english','salary-certificate-request'].flatMap(id=>[['/assets/downloads/'+id+'.pdf',200,'application/pdf'],['/assets/downloads/'+id+'.docx',200,'application/vnd.openxmlformats-officedocument.wordprocessingml.document']]));
cases.push(['/ads.txt',200,'text/plain'],['/public/ads.txt',404,'text/html']);
cases.push(...fonts.filter(f=>f.version).flatMap(f=>[['/bangla-fonts/'+f.slug+'/',200,'text/html'],['/assets/fonts/'+f.slug+'.zip',200,'application/zip'],['/assets/fonts/'+f.previewFile,200,'font/woff2']]));
cases.push(...['bengali','latin','latin-ext'].map(part=>['/assets/fonts/noto-sans-bengali-web-'+part+'.woff2',200,'font/woff2']));
cases.push(...['NotoSansBengali-Regular','NotoSerifBengali-Regular','HindSiliguri-Regular','AnekBangla-Variable'].map(name=>['/assets/fonts/'+name+'.preview.woff2',200,'font/woff2']));
const outcomes=await Promise.allSettled(cases.map(async([url,status,mime])=>{const r=await fetch(base+url);assert.equal(r.status,status,url);assert.ok(r.headers.get('content-type').includes(mime),url+' MIME');const bytes=Buffer.from(await r.arrayBuffer());if(url.endsWith('.zip'))assert.equal(bytes.readUInt32LE(0),0x04034b50);if(url.endsWith('.ttf'))assert.equal(bytes.subarray(0,4).toString('hex'),'00010000');return {url,status:r.status,bytes:bytes.length};}));
const errors=outcomes.filter(r=>r.status==='rejected');await writeFile('reports/http-smoke.json',JSON.stringify({checks:outcomes.map((r,i)=>r.status==='fulfilled'?r.value:{url:cases[i][0],error:String(r.reason)}),errors:errors.length},null,2)+'\n');assert.equal(errors.length,0,errors.map(e=>e.reason).join('\n'));console.log(`PASS ${cases.length} production HTTP/MIME checks, including missing/private URLs returning 404.`);







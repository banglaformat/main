import {beforeFinalCleanup} from './final-preservation.mjs';
import assert from 'node:assert/strict';
import {readFile,readdir,stat} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fonts} from '../scripts/font-catalog.mjs';
import './font-expansion.test.mjs';
import {applicationSalaryGuides} from '../scripts/application-salary-content.mjs';
const root=path.resolve('dist'), issues=[], warnings=[];
async function walk(dir){const files=[];for(const e of await readdir(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())files.push(...await walk(p));else files.push(p);}return files;}
const files=await walk(root), htmlFiles=files.filter(f=>f.endsWith('.html'));
const html=new Map(await Promise.all(htmlFiles.map(async f=>[f,await readFile(f,'utf8')])));
const attr=(tag,name)=>{const m=tag.match(new RegExp('(?:^|\\s)'+name+'\\s*=\\s*(?:"([^"]*)"|\'([^\']*)\'|([^\\s>]+))','i'));return m?m[1]??m[2]??m[3]:null;};
const canonicals=new Set(), titles=new Set();let links=0, structured=0;
for(const [file,text] of html){const route='/'+path.relative(root,file).replaceAll('\\','/').replace(/index\.html$/,'');
 if(/^\/(bangla-fonts|guides|converters)\//.test(route)){
  for(const expected of ['class="site-header"','class="site-footer"','id="mobileNavToggle"','id="mobileNav"','href="/assets/css/style.css"','src="/assets/js/main.js"'])if(!text.includes(expected))issues.push(`${route}: missing existing site component ${expected}`);
  if(/class="font-(header|footer)"/.test(text))issues.push(`${route}: separate site shell introduced`);
  if((text.match(/src="\/assets\/js\/main.js"/g)||[]).length!==1)issues.push(`${route}: core script duplicated`);
 }
 const canonical=[...text.matchAll(/<link\b[^>]*>/gi)].map(m=>m[0]).filter(t=>attr(t,'rel')==='canonical');
 const title=text.match(/<title>([\s\S]*?)<\/title>/i)?.[1];
 if(!title)issues.push(`${route}: missing title`);else if(titles.has(title))issues.push(`${route}: duplicate title`);else titles.add(title);
 if(!/<html[^>]+lang=["']bn["']/i.test(text))issues.push(`${route}: missing bn language`);
 if(route!='/404.html'){
  if(canonical.length!==1||attr(canonical[0]||'','href')!=='https://banglaformat.co'+route)issues.push(`${route}: canonical mismatch`);
  if(canonicals.has('https://banglaformat.co'+route))issues.push(`${route}: duplicate canonical`);canonicals.add('https://banglaformat.co'+route);
  if((text.match(/<h1\b/gi)||[]).length!==1)issues.push(`${route}: H1 count`);
  const meta=[...text.matchAll(/<meta\b[^>]*>/gi)].map(m=>m[0]);if(!meta.some(t=>attr(t,'name')==='description'&&attr(t,'content')))issues.push(`${route}: missing description`);
  if(meta.some(t=>attr(t,'name')==='robots'&&/noindex/i.test(attr(t,'content'))))issues.push(`${route}: noindex`);
 }
 for(const m of text.matchAll(/<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)){try{JSON.parse(m[1]);structured++;}catch{issues.push(`${route}: invalid JSON-LD`);}}
 for(const tag of text.matchAll(/<(?:a|link|script|img)\b[^>]*>/gi)){
  let url=attr(tag[0],/^<(script|img)/i.test(tag[0])?'src':'href');if(!url||/^(?:mailto:|tel:|javascript:|data:|https?:\/\/(?!banglaformat\.co(?:\/|$))|\/\/)/i.test(url))continue;
  url=url.replaceAll('&amp;','&');const resolved=new URL(url,'https://banglaformat.co'+route);if(resolved.origin!=='https://banglaformat.co')continue;
  const rel=decodeURIComponent(resolved.pathname).replace(/^\//,'');let target=path.join(root,rel);try{if((await stat(target)).isDirectory())target=path.join(target,'index.html');await stat(target);links++;if(resolved.hash&&html.has(target)){const id=decodeURIComponent(resolved.hash.slice(1));if(id&&!new RegExp(`\\bid=["']${id.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}["']`).test(html.get(target)))warnings.push(`${route}: missing fragment ${url}`);}}catch{issues.push(`${route}: broken local URL ${url}`);}
 }
}
// Inspect CSS dependencies as well: stylesheets and font URLs are deployment assets.
for(const file of files.filter(f=>f.endsWith('.css'))){const css=await readFile(file,'utf8');for(const m of css.matchAll(/url\(["']?([^\s)"']+)["']?\)/g)){if(!m[1].startsWith('/'))continue;try{await stat(path.join(root,m[1].slice(1)));}catch{issues.push(`CSS missing asset ${m[1]}`);}}}
const sitemap=await readFile(path.join(root,'sitemap.xml'),'utf8'), urls=[...sitemap.matchAll(/<loc>([^<]+)<\/loc>/g)].map(m=>m[1]);assert.equal(new Set(urls).size,urls.length,'Duplicate sitemap URLs');
for(const canonical of canonicals)if(!urls.includes(canonical))issues.push(`Not in sitemap: ${canonical}`);for(const url of urls)if(!canonicals.has(url))issues.push(`Noncanonical sitemap URL: ${url}`);
assert.equal(await readFile('public/sitemap.xml','utf8'),sitemap,'Sitemap copies drifted');
assert.equal(await readFile('public/llms.txt','utf8'),await readFile(path.join(root,'llms.txt'),'utf8'),'LLM reference copies drifted');
assert.equal(await readFile('public/robots.txt','utf8'),await readFile(path.join(root,'robots.txt'),'utf8'),'Robots copies drifted');
assert.equal((await readFile(path.join(root,'CNAME'),'utf8')).trim(),'banglaformat.co');assert.ok(files.includes(path.join(root,'.nojekyll')));
assert.ok(!files.some(f=>/aistudio|\.csv$|\.env|node_modules|original-route-hashes|reports[\\/]/i.test(f)),'Private or nonrelease content in output');
for(const f of fonts.filter(f=>f.file)){const bytes=await readFile(path.join(root,'assets/fonts',f.file));assert.ok(['00010000','4f54544f'].includes(bytes.subarray(0,4).toString('hex')),f.name+' invalid font');const license=await readFile(path.join(root,'assets/fonts',f.license),'utf8');assert.match(license,/OPEN FONT LICENSE|GNU GENERAL PUBLIC LICENSE/i);const zip=await readFile(path.join(root,'assets/fonts',f.slug+'.zip'));assert.equal(zip.readUInt32LE(0),0x04034b50,'Invalid ZIP');}
const provenance=JSON.parse(await readFile('assets/fonts/upstream-provenance.json','utf8'));for(const f of provenance)assert.equal(createHash('sha256').update(await readFile('assets/fonts/'+f.file)).digest('hex'),f.sha256,'Upstream file checksum mismatch');
await import('./article-improvements.test.mjs');
await import('./content-pilots.test.mjs');
await import('./final-seo.test.mjs');
await import('./performance.test.mjs');
await import('./privacy-readiness.test.mjs');
const approved=JSON.parse(await readFile('reports/content-implementation-2026-11-11/approved-changes.json','utf8')).changes;
const original=JSON.parse(await readFile('reports/original-route-hashes.json','utf8'));let preserved=0;for(const [file,hash]of Object.entries(original)){assert.ok(await stat(file),'Original route removed');if(file.startsWith('bangla-fonts/')||file==='converters/bijoy-to-unicode/index.html'||['index.html','academic-applications/index.html','office-letters-notices/index.html','cv-resume-templates/index.html'].includes(file))continue;const approvedChange=approved.find(c=>c.file===file);if(approvedChange){assert.equal(approvedChange.beforeSHA256,hash,'Approved snapshot must match original');continue;}let originalText=await beforeFinalCleanup(file,await readFile(file,'utf8'));if(file==='professional-emails/index.html'){const c=applicationSalaryGuides[0];const addition=`\n<section class="prose" aria-label="নতুন সহায়ক গাইড"><h2><a href="${c.route}">${c.h1}</a></h2><p>${c.lead}</p></section>\n`;assert.ok(originalText.includes(addition),'Expected new email guide link');originalText=originalText.replace(addition,'');}if(['cv-resume-templates/ats-friendly-cv-basic-rules/index.html','professional-emails/email-subject-line-rules-examples/index.html','professional-emails/leave-request-email-sample/index.html'].includes(file))originalText=originalText.replace('<section class="faq-section" id="faq">','<section class="faq-section">');assert.equal(createHash('sha256').update(originalText).digest('hex'),hash,'Protected page changed beyond permitted FAQ anchor repair: '+file);preserved++;}
const result={date:'2026-11-11',pages:html.size,indexablePages:canonicals.size,localReferences:links,jsonLdBlocks:structured,protectedPagesPreserved:preserved,protectedPagesByteIdentical:0,finalAdRemovalAndSchemaCleanup:true,approvedArticleImprovements:approved.length,permittedFaqAnchorRepairs:3,issues,warnings};await writeReport(result);
function writeReport(value){return import('node:fs/promises').then(fs=>fs.writeFile('reports/release-checks.json',JSON.stringify(value,null,2)+'\n'));}
if(issues.length){console.error(issues.join('\n'));process.exitCode=1;}else console.log(`PASS release: ${canonicals.size} canonical pages, ${links} local references, ${structured} valid JSON-LD blocks, ${preserved} original page content preserved (audited ad removal and three FAQ-anchor repairs); ${warnings.length} fragment warnings.`);



import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {depthRoutes,normalizeDepthContent} from '../scripts/depth-content.mjs';
for(const route of depthRoutes){const h=await readFile('dist'+route+'index.html','utf8');assert.equal(normalizeDepthContent(h,route),h,'Depth transform must be idempotent');const b=(await readFile('dist/sitemap.xml','utf8')).match(/<url>[\s\S]*?<\/url>/g).find(b=>b.includes('<loc>https://banglaformat.co'+route+'</loc>'));assert.ok(b.includes('<lastmod>2026-11-16</lastmod>'));}
const school=await readFile('dist/academic-applications/oshusthotar-karone-chutir-abedon/index.html','utf8');for(const bad of ['৩ দিনের বেশি অনুপস্থিত থাকলে চিকিৎসকের প্রেসক্রিপশন বা প্রত্যয়নপত্র জমা দেওয়া নিয়ম','ফেরার প্রথম দিনই জমা দিতে হয়'])assert.ok(!school.includes(bad));
for(const route of depthRoutes.slice(0,2)){const h=await readFile('dist'+route+'index.html','utf8');assert.equal((h.match(/id="choose-/g)||[]).length,1);assert.ok(h.includes('প্রতিষ্ঠানের'));}
console.log('PASS focused depth review: six dated routes, scoped policy advice, document selectors and idempotence.');

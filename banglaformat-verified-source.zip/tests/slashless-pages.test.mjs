import assert from 'node:assert/strict';
import {readFile,readdir,stat} from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {normalizePageUrls} from '../scripts/slashless-pages.mjs';
const root=path.resolve('dist');
async function walk(dir){let out=[];for(const e of await readdir(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())out.push(...await walk(p));else out.push(p);}return out;}
const files=await walk(root),pages=files.filter(p=>path.basename(p)==='index.html');
const routes=new Set(pages.map(p=>'/'+path.relative(root,path.dirname(p)).replaceAll(path.sep,'/')));
assert.equal(routes.size,86);assert.equal(files.filter(f=>f.endsWith('.html')).length,172);
const fixture='/contact/?x=1#editor https://banglaformat.co/contact/#editor https://other.example/contact/ /assets/fonts/file.woff2 /contact/new/';
const expected='/contact?x=1#editor https://banglaformat.co/contact#editor https://other.example/contact/ /assets/fonts/file.woff2 /contact/new/';
assert.equal(normalizePageUrls(fixture,routes),expected);
assert.equal(normalizePageUrls(expected,routes),expected);
assert.equal(normalizePageUrls('// Comment\n//external.example/contact/',routes),'// Comment\n//external.example/contact/');
for(const file of files.filter(p=>p.endsWith('.js')))assert.deepEqual(await readFile(file),await readFile(path.relative(root,file)),'Runtime JavaScript must remain byte-identical');
const sitemap=await readFile('dist/sitemap.xml','utf8');
assert.deepEqual(new Set([...sitemap.matchAll(/<loc>(.*?)<\/loc>/g)].map(m=>new URL(m[1]).pathname)),routes);
let references=0;
for(const page of pages){
 const route='/'+path.relative(root,path.dirname(page)).replaceAll(path.sep,'/');
 const html=await readFile(page,'utf8');
 assert.ok(html.includes(`rel="canonical" href="https://banglaformat.co${route}"`),route+' canonical');
 assert.ok(html.includes(`property="og:url" content="https://banglaformat.co${route}"`),route+' OG');
 if(route!=='/')assert.equal(await readFile(path.dirname(page)+'.html','utf8'),html,'Compatibility copy differs: '+route);
 for(const m of html.matchAll(/(?:href|src)="([^"]+)"/g)){
  const u=new URL(m[1].replaceAll('&amp;','&'),'https://banglaformat.co'+route);
  if(u.origin!=='https://banglaformat.co')continue;
  if(u.pathname!=='/'&&u.pathname.endsWith('/')&&routes.has(u.pathname.slice(0,-1)))assert.fail('Old slash link '+u);
  let target=path.join(root,decodeURIComponent(u.pathname));
  if(routes.has(u.pathname)&&u.pathname!=='/')target+='.html';
  else if((await stat(target)).isDirectory())target=path.join(target,'index.html');
  await stat(target);references++;
  if(u.hash&&target.endsWith('.html')){
   const linked=await readFile(target,'utf8');
   assert.ok(linked.includes(`id="${decodeURIComponent(u.hash.slice(1))}"`)||linked.includes(`id='${decodeURIComponent(u.hash.slice(1))}'`),'Missing anchor '+u);
  }
 }
 for(const m of html.matchAll(/<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g)){
  const graph=JSON.parse(m[1]);
  function check(v){if(typeof v==='string'&&v.startsWith('https://banglaformat.co/')){const u=new URL(v);assert.ok(u.pathname==='/'||!u.pathname.endsWith('/')||!routes.has(u.pathname.slice(0,-1)),'Old schema URL '+v);}else if(v&&typeof v==='object')Object.values(v).forEach(check);}
  check(graph);
 }
}
const preview=spawn(process.execPath,['scripts/serve-static.mjs'],{env:{...process.env,PORT:'4182'},stdio:['ignore','pipe','pipe']});
try{
 await new Promise((resolve,reject)=>{preview.stdout.once('data',resolve);preview.once('error',reject);preview.once('exit',code=>reject(Error('Preview exited '+code)));});
 for(const route of routes){
  for(const suffix of route==='/'?['']:['','/']){
   const r=await fetch('http://127.0.0.1:4182'+route+suffix+'?test=1',{redirect:'manual'});
   assert.equal(r.status,200,route+suffix);assert.equal(r.headers.get('location'),null);
   assert.ok((await r.text()).includes(`rel="canonical" href="https://banglaformat.co${route}"`));
  }
 }
 assert.equal((await fetch('http://127.0.0.1:4182/missing-page')).status,404);
 const head=await fetch('http://127.0.0.1:4182/contact',{method:'HEAD'});assert.equal(head.status,200);assert.equal(await head.text(),'');
}finally{preview.kill();}
console.log(`PASS final GitHub Pages layout: 86 slashless canonicals, 85 identical compatibility pages, ${references} local links/assets/anchors, schema/sitemap alignment and 171 HTTP route responses.`);

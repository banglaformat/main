import assert from 'node:assert/strict';
import {createServer} from 'vite';

// Exercise the actual dev middleware with an OS-assigned port, including in AI Studio HMR mode.
const server = await createServer({server: {host: '127.0.0.1', port: 0, open: false}});
try {
  await server.listen();
  const base = `http://127.0.0.1:${server.httpServer.address().port}`;
  const checks = [
    ['/', 200, 'text/html'], ['/bangla-fonts/', 200, 'text/html'],
    ['/converters/bijoy-to-unicode/', 200, 'text/html'],
    ['/assets/js/main.js', 200, 'javascript'], ['/assets/js/font-library.js', 200, 'javascript'],
    ['/assets/fonts/NotoSansBengali-Regular.ttf', 200, 'font/ttf'],
    ['/not-a-real-page/', 404, 'text/html'], ['/assets/missing.js', 404, 'text/html'],
    ['/package.json', 404, 'text/html'], ['/reports/github-ai-studio-readiness-2026-11-11/verification.json', 404, 'text/html'],
    ['/public/assets/aistudio/Queries_03d811bf.csv', 404, 'text/html'],
    ['/assets/aistudio/Queries_03d811bf.csv', 404, 'text/html'],
    ['/tmp/github-readiness-source/index.html', 404, 'text/html'],
    ['/.env', 404, 'text/html'], ['/%ZZ', 404, 'text/html'],
    ['/assets/%2e%2e%5cpackage.json', 404, 'text/html'],
    ['/@fs/C:/Windows/win.ini', 404, 'text/html'],
    ['/@vite/client', 200, 'javascript'],
  ];
  for (const [url, status, type] of checks) {
    const response = await fetch(base + url);
    assert.equal(response.status, status, url);
    assert.ok(response.headers.get('content-type')?.includes(type), `${url} MIME`);
    await response.arrayBuffer();
  }
  const redirect = await fetch(base + '/bangla-fonts?search=Noto', {redirect: 'manual'});
  assert.equal(redirect.status, 301);
  assert.equal(redirect.headers.get('location'), '/bangla-fonts/?search=Noto');
  const page = await (await fetch(base + '/bangla-fonts')).text();
  assert.match(page, /id="font-search"/);
  const head = await fetch(base + '/assets/missing.js', {method: 'HEAD'});
  assert.equal(head.status, 404);
  assert.equal((await head.text()).length, 0);
  console.log(`PASS ${checks.length + 3} dev routing, content-type, privacy and redirect checks.`);
} finally {
  await server.close();
}

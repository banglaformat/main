import {beforeFinalCleanup} from './final-preservation.mjs';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const manifest=JSON.parse(await readFile('reports/content-implementation-2026-11-11/approved-changes.json','utf8'));
function normalize(text){return text.replace(/\n      <!-- content-entry:start -->[\s\S]*?      <!-- content-entry:end -->\n/,'').replace(/\n      <!-- content-sample:start -->[\s\S]*?      <!-- content-sample:end -->\n/,'').replace(/<title>[\s\S]*?<\/title>/,'<title/>').replace(/<h1\b[^>]*>[\s\S]*?<\/h1>/,'<h1/>').replace(/<meta\b[^>]*>/g,t=>/(?:name|property)="(?:description|og:description|twitter:description|og:title|twitter:title)"/.test(t)?t.replace(/content="[^"]*"/,'content="APPROVED_METADATA"'):t).replace(/"dateModified":\s*"[^"]*"/g,'"dateModified": "APPROVED_DATE"').replace(/"headline":\s*"[^"]*"/g,'"headline": "APPROVED_HEADLINE"').replace(/আপডেট: (?:১১ নভেম্বর ২০২৬|২০২৬)/g,'আপডেট: APPROVED_DATE');}
for(const change of manifest.changes){const before=await readFile(change.snapshot,'utf8'),after=await beforeFinalCleanup(change.file,await readFile(change.file,'utf8'));assert.equal(createHash('sha256').update(before).digest('hex'),change.beforeSHA256);assert.equal(createHash('sha256').update(after).digest('hex'),change.afterSHA256);let restored=after.replace(/\n      <!-- ngo-drafts:start -->[\s\S]*?      <!-- ngo-drafts:end -->\n/,'');for(const r of change.replacements||[]){assert.ok(restored.includes(r.after));restored=restored.replace(r.after,r.before);}assert.equal(normalize(restored),normalize(before),'Unexpected content change: '+change.file);
 const ids=[...after.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);const entry=after.match(/<!-- content-entry:start -->([\s\S]*?)<!-- content-entry:end -->/)[1];for(const m of entry.matchAll(/href="#([^"]+)"|data-copy-target="([^"]+)"/g)){assert.equal(ids.filter(id=>id===(m[1]||m[2])).length,1,'Ambiguous or missing shortcut/copy target');}
 for(const m of before.matchAll(/<div class="template-content"[^>]*>[\s\S]*?<\/div>/g))assert.ok(after.includes(m[0]),'Existing sample changed');
}
console.log(`PASS ${manifest.changes.length} article improvements: only approved additions, FAQ corrections and metadata changed; original samples preserved.`);


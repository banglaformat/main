import {publisher,adsTxt} from '../scripts/adsense-config.mjs';
import {readFile,readdir,stat,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import path from 'node:path';
const root=path.resolve('dist');
const plain=s=>s.replace(/<script\b[\s\S]*?<\/script>/gi,'').replace(/<style\b[\s\S]*?<\/style>/gi,'').replace(/<[^>]*>/g,'').replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/\s+/g,' ').trim();
async function walk(d){let out=[];for(const e of await readdir(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())out.push(...await walk(p));else out.push(p);}return out;}
const files=await walk(root),pages=files.filter(f=>f.endsWith('.html')),routes=new Map(),edges=new Map();let schemas=0;
assert.equal(await readFile('dist/ads.txt','utf8'),adsTxt);
assert.equal(await readFile('public/ads.txt','utf8'),adsTxt);
for(const file of files.filter(f=>/\.(html|js|css|txt|xml|json)$/.test(f))){const text=await readFile(file,'utf8');for(const m of text.matchAll(/(?:ca-)?pub-(\d+)/g))assert.equal(m[1],publisher,'Old/unknown publisher ID in '+file);}
for(const file of pages){const html=await readFile(file,'utf8'),route='/'+path.relative(root,file).replaceAll('\\','/').replace('index.html','');routes.set(route,html);const links=[...html.matchAll(/<a\b[^>]*href="([^"#]+)[^"]*"/g)].map(m=>new URL(m[1],'https://banglaformat.co'+route)).filter(u=>u.origin==='https://banglaformat.co').map(u=>u.pathname);edges.set(route,links);
 const accountTags=[...html.matchAll(/<meta\b[^>]*name="google-adsense-account"[^>]*>/g)];const loaders=[...html.matchAll(/<script\b[^>]*src="[^"]*adsbygoogle\.js[^>]*>/g)];assert.equal(accountTags.length,route==='/404.html'?0:1,route+' account count');assert.equal(loaders.length,route==='/404.html'?0:1,route+' loader count');if(loaders.length){assert.ok(loaders[0][0].includes('async'));assert.ok(loaders[0][0].includes('crossorigin="anonymous"'));assert.ok(loaders[0][0].includes('ca-pub-'+publisher));}
 const visible=plain(html.match(/<main\b[\s\S]*?<\/main>/)?.[0]||html);
 for(const target of html.matchAll(/data-copy-target="([^"]+)"/g))assert.equal([...html.matchAll(/\bid="([^"]+)"/g)].filter(m=>m[1]===target[1]).length,1,route+' missing or ambiguous copy target');
 if(route!='/404.html'){assert.ok(!/name="robots"[^>]*content="[^"]*(?:noindex|nosnippet)/.test(html),route+' blocks search');assert.ok(html.includes(`property="og:url" content="https://banglaformat.co${route}"`),route+' OG URL mismatch');}
 else assert.match(html,/name="robots" content="noindex, follow"/);
 for(const m of html.matchAll(/<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g)){const graph=JSON.parse(m[1]);schemas++;function visit(o){if(!o||typeof o!=='object')return;if(typeof o.name==='string')assert.ok(!/<[^>]+>/.test(o.name),route+' schema name contains HTML');if(o['@type']==='Question'){assert.ok(visible.includes(plain(o.name)),route+' FAQ schema question not visible');assert.ok(visible.includes(plain(o.acceptedAnswer?.text||'')),route+' FAQ schema answer not visible');}if(o['@type']==='BreadcrumbList'){let position=0;for(const item of o.itemListElement){assert.equal(item.position,++position);assert.ok(item.name&&item.item);}}for(const value of Object.values(o))if(typeof value==='object')Array.isArray(value)?value.forEach(visit):visit(value);}visit(graph);}
}
const seen=new Set(['/']),pending=['/'];while(pending.length){const route=pending.pop();for(const next of edges.get(route)||[])if(routes.has(next)&&!seen.has(next)){seen.add(next);pending.push(next);}}
const orphaned=[...routes.keys()].filter(r=>r!='/404.html'&&!seen.has(r));assert.deepEqual(orphaned,[],'Canonical pages not reachable through HTML links');
const headers=await readFile('dist/_headers','utf8');assert.ok(!/immutable/.test(headers.replace(/^#.*$/gm,'')),'Stable filename assets cached immutable');
const report={pages:pages.length,indexablePages:pages.length-1,adsensePublisher:publisher,legacyPublisherOccurrences:0,advertisingAuthorizationFiles:1,schemasChecked:schemas,orphanedCanonicalPages:orphaned,notes:'Local static validation; does not prove external indexing, rich results, AI citations or rankings.'};await writeFile('reports/final-audit-2026-11-11/verification.json',JSON.stringify(report,null,2)+'\n');console.log(`PASS final SEO/current-publisher audit: ${pages.length-1} reachable canonical pages, ${schemas} schema blocks, one current publisher and no legacy publisher IDs.`);


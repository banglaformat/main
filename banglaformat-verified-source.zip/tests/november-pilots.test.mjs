import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {novemberPilots} from '../scripts/november-pilot-content.mjs';
const esc=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
for(const p of novemberPilots){
 const route=`/${p.category}/${p.slug}/`,html=await readFile('dist'+route+'index.html','utf8');
 assert.ok(html.includes(`rel="canonical" href="https://banglaformat.co${route}"`));
 for(const [key,text]of [['bangla',p.bn],['english',p.en]]){
  assert.ok(html.includes(`id="${p.slug}-${key}">${esc(text)}</div>`),'Sample text missing');
  assert.equal(await readFile(`dist/assets/downloads/${p.slug}-${key}.txt`,'utf8'),text+'\n');
  assert.ok(html.includes(`data-copy-target="${p.slug}-${key}"`));
 }
 assert.ok((await readFile(`dist/${p.category}/index.html`,'utf8')).includes(`href="${route}"`));
 assert.ok(html.includes('data-print-guide'));
 assert.ok(!html.includes(`${p.slug}.docx`)&&!html.includes(`${p.slug}.pdf`),'Unverified office downloads linked');
 assert.ok((await readFile('dist/sitemap.xml','utf8')).includes('<loc>https://banglaformat.co'+route+'</loc>'));
}
console.log(`PASS November guides: ${novemberPilots.length} canonical pages, ${novemberPilots.length*2} matching downloads, copy targets, print controls and hub discovery.`);

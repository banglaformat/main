import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fonts,fontTotals} from '../scripts/font-catalog.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex');
const records=JSON.parse(await readFile('dist/assets/fonts/font-source-register.json','utf8'));
assert.equal(fontTotals.additions,22,'Only verified additions may be released; target shortfall must remain explicit');
assert.equal(fontTotals.families,29);assert.equal(fontTotals.downloads,26);
assert.equal(new Set(fonts.map(f=>f.name.toLowerCase().trim())).size,fonts.length);
assert.equal(new Set(fonts.map(f=>f.slug)).size,fonts.length);
assert.equal(records.length,22);assert.equal(new Set(records.map(r=>r.sha256)).size,22);
const hub=await readFile('dist/bangla-fonts/index.html','utf8');
assert.equal((hub.match(/data-font-card/g)||[]).length,29);assert.equal((hub.match(/data-compare=/g)||[]).length,26);
for(const r of records){
 for(const [file,expected] of [[r.file,r.sha256],[r.previewFile,r.previewSha256],[r.slug+'.zip',r.zipSha256]])assert.equal(hash(await readFile('dist/assets/fonts/'+file)),expected,file);
 assert.ok(r.author&&r.version&&r.source&&r.encoding&&r.demandEvidence&&r.licenseId);
 const page=await readFile(`dist/bangla-fonts/${r.slug}/index.html`,'utf8');assert.ok(hub.includes(`/bangla-fonts/${r.slug}/`));assert.ok(page.includes(r.sha256));assert.ok(page.includes(r.licenseId));assert.ok(page.includes(r.style));
 assert.ok(page.includes('কার্যক্রম, শিক্ষা, শ্রদ্ধা, জ্ঞান'));assert.ok(page.includes('এই তালিকা জনপ্রিয়তার র‍্যাঙ্কিং নয়।'));
 if(r.licenseId.startsWith('GPL'))assert.ok(r.packageContents.includes('source.tar.gz'));
 assert.ok(!hub.includes(`<link rel="preload" href="/assets/fonts/${r.previewFile}`));
}
const js=await readFile('dist/assets/js/font-library.js','utf8');assert.ok(js.includes("el.dataset.weightRange||'400'"));assert.ok(!js.includes('else samples.forEach(loadFont)'));
console.log('PASS font expansion: 22 verified additions, 29 unique families, 26 local downloads; hashes, notices, sources, routes and generated totals.');

# Bijoy ↔ Unicode conversion

Browser engine: `assets/js/bijoy-engine.js` (no external JS dependency). UI: `assets/js/bijoy-converter.js`.

Run regression tests: `node tests/bijoy-converter.test.cjs`.

Supported: common SutonnyMJ/Bijoy ANSI character mappings, frequent conjunct glyphs, reph, pre-base vowels, Bengali digits, bidirectional conversion, line breaks. 181 glyph mappings.

Important limitations: Bijoy ANSI and ordinary English use overlapping ASCII bytes. A plain-text converter cannot reliably detect which spans were typed in English. Convert only legacy-encoded Bengali runs; manually protect English sections. Font/version-specific glyphs, uncommon conjuncts, malformed input, and ZWJ/ZWNJ may be lossy. Round-trip passing does not prove typographic fidelity. No proprietary fonts bundled.

Release gate: manually compare a representative corpus of original SutonnyMJ documents and converted Unicode results, and verify reverse conversion visually with a separately licensed Bijoy font. This ZIP has source-level automated tests, not a production browser test or Vite build.

import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {slug,bangla,english} from '../scripts/generate-return-guide.mjs';
const esc=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const route='/office-letters-notices/'+slug+'/',h=await readFile('dist'+route+'index.html','utf8');
for(const [key,text]of [['bangla',bangla],['english',english]]){assert.equal(await readFile('dist/assets/downloads/'+slug+'-'+key+'.txt','utf8'),text+'\n');assert.ok(h.includes('id="'+slug+'-'+key+'">'+esc(text)+'</div>'));assert.ok(h.includes('data-copy-target="'+slug+'-'+key+'"'));}
assert.ok(h.includes('আগামী দিনে ফেরার খবর দিচ্ছেন'));assert.ok(h.includes('কোনো প্রতিষ্ঠানের ছুটির নিয়ম বা হাজিরা গণনার নির্দেশনা নয়'));
assert.equal(new Date('2026-11-19T00:00:00Z').getUTCDay(),4);assert.equal(new Date('2026-11-22T00:00:00Z').getUTCDay(),0);
assert.ok(h.includes('data-print-guide'));assert.ok(!h.includes(slug+'.pdf')&&!h.includes(slug+'.docx'));
assert.equal(((await readFile('dist/office-letters-notices/index.html','utf8')).match(new RegExp('<!-- return-guide:'+slug+' -->','g'))||[]).length,1);
assert.ok((await readFile('dist/sitemap.xml','utf8')).includes('<loc>https://banglaformat.co'+route+'</loc>'));
const graph=JSON.parse(h.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);assert.equal(graph['@graph'][0].mainEntityOfPage,'https://banglaformat.co'+route);assert.equal(graph['@graph'][0].author['@type'],'Organization');
console.log('PASS return guide: text/download parity, date example, clear sample scopes, copy and print controls, hub discovery and organization attribution.');

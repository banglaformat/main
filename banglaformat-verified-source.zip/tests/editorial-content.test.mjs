import {normalizeDepthContent,depthRoutes} from '../scripts/depth-content.mjs';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {editorialEdits,editorialRoutes,normalizeEditorialContent,plain} from '../scripts/editorial-content.mjs';
import {normalizeSeoContent} from '../scripts/seo-content.mjs';
for(const route of [...new Set(editorialEdits.map(e=>e.route))]){
 const file=route==='/404.html'?'404.html':route.slice(1)+'index.html';
 const built=await readFile('dist/'+file,'utf8');
 const visible=plain(built.slice(built.indexOf('<body')).replace(/<script\b[\s\S]*?<\/script>|<div class="template-content"[^>]*>[\s\S]*?<\/div>/g,''));
 for(const e of editorialEdits.filter(e=>e.route===route)){
  assert.ok(plain(built).includes(e.after),route+' missing revised passage: '+e.before.slice(0,35));
  assert.ok(!visible.includes(e.before),route+' superseded wording still visible: '+e.before.slice(0,35));
 }
 assert.equal(normalizeDepthContent(normalizeEditorialContent(built,route),route),built,'Editorial processing must be idempotent: '+route);
 const source=normalizeSeoContent(await readFile(file,'utf8'),route);
 const samples=t=>[...t.matchAll(/<div class="template-content"[^>]*>[\s\S]*?<\/div>/g)].map(m=>m[0]);
 assert.deepEqual(samples(built),samples(source),'Copyable sample changed without review: '+route);
}
async function walk(dir){const out=[];for(const e of await readdir(dir,{withFileTypes:true})){const p=dir+'/'+e.name;if(e.isDirectory())out.push(...await walk(p));else if(e.name.endsWith('.html'))out.push(p);}return out;}
for(const file of await walk('dist')){
 const html=await readFile(file,'utf8');
 assert.ok(!html.includes('অভিজ্ঞ মানব সম্পাদক (Hiam) কর্তৃক'),'Unverified human review claim remains');
 assert.ok(!html.includes('প্রতিটি ফরম্যাট ও লেখা তিনি ব্যক্তিগতভাবে পর্যালোচনা করেন'),'Unverified personal review claim remains');
 assert.ok(!html.includes('প্রফেশনাল কমিউনিকেশন বিষয়ে বিশেষজ্ঞ'),'Unverified expertise claim remains');
}
const policy=await readFile('dist/editorial-policy/index.html','utf8');assert.ok(policy.includes('AI সহায়তা ব্যবহার করা হয়েছে'));
const sitemap=await readFile('dist/sitemap.xml','utf8');
for(const route of editorialRoutes){const block=sitemap.match(/<url>[\s\S]*?<\/url>/g).find(b=>b.includes('<loc>https://banglaformat.co'+route+'</loc>'));assert.ok(block?.includes('<lastmod>'+(depthRoutes.includes(route)?'2026-11-16':'2026-11-15')+'</lastmod>'),'Editorial date mismatch '+route);}
console.log(`PASS editorial review: ${editorialEdits.length} revised passages, ${editorialRoutes.length} dated canonical routes, unchanged samples and truthful review disclosure.`);

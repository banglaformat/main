import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {normalizeSeoContent, seoUpdatedRoutes} from '../scripts/seo-content.mjs';
for (const route of seoUpdatedRoutes) {
  const file=route.slice(1)+'index.html';
  const source=await readFile(file,'utf8');
  const once=normalizeSeoContent(source,route);
  assert.equal(normalizeSeoContent(once,route),once,'Content processing must be idempotent');
  const built=await readFile('dist/'+file,'utf8');
  assert.ok(built.includes('আপডেট: ১৪ নভেম্বর ২০২৬'));
  assert.ok(built.includes('https://banglaformat.co'+route));
  assert.ok(!built.includes('বাংলাদেশ শ্রম আইন ও করপোরেট শিষ্টাচার অনুযায়ী'));
  for (const m of built.matchAll(/<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g)) JSON.parse(m[1]);
}
const about=await readFile('dist/about/index.html','utf8');assert.ok(about.includes('id="editor"'));
const sitemap=await readFile('dist/sitemap.xml','utf8');
for (const route of seoUpdatedRoutes) assert.ok(sitemap.includes('<loc>https://banglaformat.co'+route+'</loc>'));
assert.equal((sitemap.match(/<lastmod>2026-11-14<\/lastmod>/g)||[]).length,3,'Only substantively edited article dates change');
console.log('PASS SEO corrections: three article scopes, schema syntax, profile target, idempotence and three sitemap dates.');

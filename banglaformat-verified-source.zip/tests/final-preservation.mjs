import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const manifest=JSON.parse(await readFile('reports/final-audit-2026-11-11/changes.json','utf8'));
export async function beforeFinalCleanup(file,text){const change=manifest.changes.find(c=>c.file===file);if(!change)return text;const sha=s=>createHash('sha256').update(s).digest('hex');assert.equal(sha(text),change.afterSHA256,'Unexpected modification after final audit: '+file);const before=await readFile(change.snapshot,'utf8');assert.equal(sha(before),change.beforeSHA256,'Final audit snapshot mismatch');return before;}

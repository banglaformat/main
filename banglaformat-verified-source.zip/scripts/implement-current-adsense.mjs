import {applyPrivacyContent} from './privacy-content.mjs';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {applyAdsense,adsTxt} from './adsense-config.mjs';
const manifestPath='reports/final-audit-2026-11-11/changes.json',manifest=JSON.parse(await readFile(manifestPath,'utf8'));
const report='reports/adsense-update-2026-11-11';await mkdir(report+'/before',{recursive:true});
const sha=s=>createHash('sha256').update(s).digest('hex');let count=0;
for(const entry of manifest.changes){const before=await readFile(entry.file,'utf8');let after=applyAdsense(before);if(entry.file==='privacy-policy/index.html')after=applyPrivacyContent(after);if(after===before)continue;await writeFile(report+'/before/'+entry.file.replaceAll('/','__'),before);await writeFile(entry.file,after);entry.afterSHA256=sha(after);count++;}
for(const file of ['ads.txt','public/ads.txt'])await writeFile(file,adsTxt);
await writeFile(manifestPath,JSON.stringify(manifest,null,2)+'\n');console.log(`Updated ${count} pages and both ads.txt source copies to the current publisher.`);


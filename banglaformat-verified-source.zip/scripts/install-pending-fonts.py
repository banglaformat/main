#!/usr/bin/env python3
"""Install verified upstream font binaries. Run from repository root: python scripts/install-pending-fonts.py
Requires network access to GitHub. Does not fetch proprietary ANSI fonts.
"""
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError
import hashlib, json, re, sys
ROOT=Path(__file__).resolve().parents[1]
FONTS=ROOT/'assets/fonts'
FONTS.mkdir(parents=True,exist_ok=True)
# Official Google Fonts source repository, licensed under SIL OFL 1.1.
SOURCES={
 'hind-siliguri': ('https://raw.githubusercontent.com/google/fonts/main/ofl/hindsiliguri/HindSiliguri-Regular.ttf', 'HindSiliguri-Regular.ttf', 'https://raw.githubusercontent.com/google/fonts/main/ofl/hindsiliguri/OFL.txt'),
 'anek-bangla': ('https://raw.githubusercontent.com/google/fonts/main/ofl/anekbangla/AnekBangla%5Bwdth%2Cwght%5D.ttf', 'AnekBangla-Variable.ttf', 'https://raw.githubusercontent.com/google/fonts/main/ofl/anekbangla/OFL.txt'),
}
def fetch(url):
    req=Request(url,headers={'User-Agent':'BanglaFormat-font-installer/1.0'})
    with urlopen(req,timeout=30) as response:return response.read()
def install(slug,url,filename,license_url):
    try:
        binary=fetch(url); license_text=fetch(license_url)
        if binary[:4] not in (b'\x00\x01\x00\x00',b'OTTO',b'ttcf'):
            raise ValueError('Invalid font signature')
        if b'SIL OPEN FONT LICENSE' not in license_text.upper():raise ValueError('Expected OFL license missing')
        (FONTS/filename).write_bytes(binary)
        (FONTS/(slug+'-OFL.txt')).write_bytes(license_text)
        print('INSTALLED',slug,filename,'SHA256',hashlib.sha256(binary).hexdigest())
        return True
    except Exception as exc:
        print('NOT INSTALLED',slug,str(exc),file=sys.stderr);return False

if __name__=='__main__':
    count=sum(install(slug,*source) for slug,source in SOURCES.items())
    print('Installed',count,'of',len(SOURCES),'official Google Fonts families')
    if count != len(SOURCES):sys.exit(1)

import {readFile,readdir,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
for(const test of ['scripts/build-static.mjs','tests/bijoy-converter.test.cjs','tests/release.test.mjs']){const result=spawnSync(process.execPath,[test],{stdio:'inherit'});if(result.status!==0)throw Error('Release build or validation failed; archive not updated');}
// Standard ZIP, stored entries. No third-party packaging dependencies.
const root=path.resolve('dist');
async function walk(dir){let list=[];for(const e of await readdir(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())list.push(...await walk(p));else list.push(p);}return list;}
const table=Array.from({length:256},(_,n)=>{for(let i=0;i<8;i++)n=(n&1)?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
const crc=b=>{let n=0xffffffff;for(const v of b)n=table[(n^v)&255]^(n>>>8);return (n^0xffffffff)>>>0;};
let offset=0;const local=[],central=[],manifest=[];
for(const file of (await walk(root)).sort()){
 const data=await readFile(file),name=path.relative(root,file).replaceAll('\\','/'),bytes=Buffer.from(name),sum=crc(data);
 const header=Buffer.alloc(30);header.writeUInt32LE(0x04034b50);header.writeUInt16LE(20,4);header.writeUInt16LE(0x800,6);header.writeUInt16LE(0x5d6b,12);header.writeUInt32LE(sum,14);header.writeUInt32LE(data.length,18);header.writeUInt32LE(data.length,22);header.writeUInt16LE(bytes.length,26);
 local.push(header,bytes,data);
 const entry=Buffer.alloc(46);entry.writeUInt32LE(0x02014b50);entry.writeUInt16LE(20,4);entry.writeUInt16LE(20,6);entry.writeUInt16LE(0x800,8);entry.writeUInt16LE(0x5d6b,14);entry.writeUInt32LE(sum,16);entry.writeUInt32LE(data.length,20);entry.writeUInt32LE(data.length,24);entry.writeUInt16LE(bytes.length,28);entry.writeUInt32LE(offset,42);central.push(entry,bytes);offset+=header.length+bytes.length+data.length;
 manifest.push({path:name,bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')});
}
const directory=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(manifest.length,8);end.writeUInt16LE(manifest.length,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);
await mkdir('release',{recursive:true});const zip=Buffer.concat([...local,directory,end]);await writeFile('release/banglaformat-production.zip',zip);await writeFile('release/manifest.json',JSON.stringify({date:'2026-11-11',archiveSHA256:createHash('sha256').update(zip).digest('hex'),files:manifest},null,2)+'\n');console.log(`Packaged ${manifest.length} files; ${(zip.length/1024/1024).toFixed(2)} MiB.`);

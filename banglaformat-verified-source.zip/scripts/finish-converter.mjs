import {readFile,writeFile} from 'node:fs/promises';
import {applySiteShell} from './shared-site-shell.mjs';
const enginePath='assets/js/bijoy-engine.js';
let s=await readFile(enginePath,'utf8');s=s.replace("direction==='bijoy'&&ascii&&!highLegacy","direction==='bijoy'&&ascii");await writeFile(enginePath,s);
let h=await readFile('converters/bijoy-to-unicode/index.html','utf8');
h=h.replace('<strong>গুরুত্বপূর্ণ:</strong>','<strong>সীমিত ম্যাপিং: ফল মিলিয়ে নিন।</strong>').replace('বিজয় ANSI ও ইংরেজি একই ASCII অক্ষর ব্যবহার করতে পারে।','বিজয় ANSI ও ইংরেজি একই ASCII অক্ষর ব্যবহার করতে পারে। শুধু legacy বাংলা অংশ রূপান্তর করুন; ইংরেজি অংশ আলাদা রাখুন।').replace('<textarea id="convert-input"','<textarea maxlength="100000" id="convert-input"');
if(!h.includes('/guides/bangla-font-fix/'))h=h.replace('</section></div></main>','<p><a href="/guides/bangla-font-fix/">Word ও PDF-এ বাংলা সমস্যার সমাধান</a> · <a href="/guides/install-bangla-font/">ফন্ট ইনস্টল গাইড</a></p></section></div></main>');
if(h.includes('class="font-header"')){h=h.replace('/assets/css/font-platform.css','/assets/css/font-library.css');h=applySiteShell(h,'/converters/bijoy-to-unicode/');}
await writeFile('converters/bijoy-to-unicode/index.html',h);

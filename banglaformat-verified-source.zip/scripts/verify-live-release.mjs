import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const origin='https://banglaformat.co',manifest=JSON.parse(await readFile('release/manifest.json','utf8'));
const checks=[],queue=[...manifest.files].filter(f=>!['.nojekyll','CNAME','_headers'].includes(f.path));
const hash=b=>createHash('sha256').update(b).digest('hex');
async function worker(){while(queue.length){const f=queue.shift();try{const r=await fetch(origin+'/'+f.path.replace(/index\.html$/,''),{signal:AbortSignal.timeout(30000)});const b=Buffer.from(await r.arrayBuffer());checks.push({path:f.path,status:r.status,url:r.url,sha256:hash(b),expectedSHA256:f.sha256,pass:r.status===200&&hash(b)===f.sha256});}catch(e){checks.push({path:f.path,pass:false,error:String(e)});}}}
await Promise.all(Array.from({length:5},worker));
const extras=[];
for(const [route,status,type] of [['/ads.txt',200,'text/plain'],['/not-a-real-page-release-check/',404,'text/html'],['/public/assets/aistudio/Queries_03d811bf.csv',404,'text/html'],['/reports/final-audit-2026-11-11/changes.json',404,'text/html']]){
 try{const r=await fetch(origin+route,{signal:AbortSignal.timeout(30000)}),body=await r.text();extras.push({route,status:r.status,contentType:r.headers.get('content-type'),pass:r.status===status&&(r.headers.get('content-type')||'').includes(type)&&(!route.endsWith('ads.txt')||body.trim()==='google.com, pub-5724834317757008, DIRECT, f08c47fec0942fa0')});}catch(e){extras.push({route,pass:false,error:String(e)});}
}
const http=await fetch('http://banglaformat.co/',{redirect:'manual'});extras.push({route:'http://banglaformat.co/',status:http.status,location:http.headers.get('location'),pass:[301,302,307,308].includes(http.status)&&(http.headers.get('location')||'').startsWith('https://banglaformat.co')});
const result={checkedAt:new Date().toISOString(),origin,archiveSHA256:manifest.archiveSHA256,files:checks.sort((a,b)=>a.path.localeCompare(b.path)),extras,errors:checks.filter(c=>!c.pass).length+extras.filter(c=>!c.pass).length};
await mkdir('reports/live-deployment-2026-11-11',{recursive:true});await writeFile('reports/live-deployment-2026-11-11/verification.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({files:checks.length,extras:extras.length,errors:result.errors,failures:[...checks,...extras].filter(c=>!c.pass)},null,2));
if(result.errors)process.exitCode=1;

// Supply the shared styles before the first layout, avoiding a late page-wide restyle.
// Keep assets/css/style.css as the single source of truth for build and preview.
export function inlineSiteStyles(html, css) {
  if (!css.trim() || /<\/style/i.test(css)) throw new Error('Invalid shared stylesheet');
  const style = '<style data-site-styles>' + css + '</style>';
  const existing = /<style data-site-styles>[\s\S]*?<\/style>/;
  if (existing.test(html)) return html.replace(existing, () => style);
  const link = /<link\b(?=[^>]*\brel="stylesheet")(?=[^>]*\bhref="\/assets\/css\/style\.css")[^>]*>/;
  if (!link.test(html)) throw new Error('Shared stylesheet link is missing');
  return html.replace(link, () => style);
}

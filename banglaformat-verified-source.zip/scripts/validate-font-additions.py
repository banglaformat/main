"""Binary, archive, license/source, lossless layout and HarfBuzz specimen checks."""
from pathlib import Path
import sys,json,hashlib,zipfile,io,tarfile,re,unicodedata
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'tmp/font-tools'))
from fontTools.ttLib import TTFont
from fontTools.pens.recordingPen import DecomposingRecordingPen
import uharfbuzz as hb
assets=root/'assets/fonts';register=json.loads((assets/'font-source-register.json').read_text(encoding='utf-8'))
results=[];seen=set();outlines=set()
for row in register:
 data=(assets/row['file']).read_bytes();f=TTFont(io.BytesIO(data));p=TTFont(assets/row['previewFile']);sha=lambda b:hashlib.sha256(b).hexdigest()
 assert sha(data)==row['sha256'];assert sha((assets/row['previewFile']).read_bytes())==row['previewSha256'];assert sha((assets/(row['slug']+'.zip')).read_bytes())==row['zipSha256'];assert row['sha256'] not in seen;seen.add(row['sha256'])
 assert data[:4] in [b'\0\1\0\0',b'OTTO'];assert f.getBestCmap()==p.getBestCmap();assert f['hmtx'].metrics==p['hmtx'].metrics
 assert f.getGlyphOrder()==p.getGlyphOrder()
 for tag in ['GSUB','GPOS']:
  if tag in f:assert f[tag].compile(f)==p[tag].compile(p)
 if 'fvar' in f:assert [(a.axisTag,a.minValue,a.defaultValue,a.maxValue) for a in f['fvar'].axes]==[(a.axisTag,a.minValue,a.defaultValue,a.maxValue) for a in p['fvar'].axes]
 with zipfile.ZipFile(assets/(row['slug']+'.zip')) as z:
  assert z.testzip() is None;assert z.read(row['originalFile'])==data;assert z.read(row['license'])==(assets/row['license']).read_bytes();assert sorted(z.namelist())==sorted(row['packageContents'])
  if row['sourceSha256']:
   source=z.read('source.tar.gz');assert sha(source)==row['sourceSha256']
   with tarfile.open(fileobj=io.BytesIO(source)) as t:
    assert any(n.endswith('.sfd') for n in t.getnames());assert any(n.endswith('generate.pe') for n in t.getnames());assert any(n.endswith(('/LICENCE','/LICENSE')) for n in t.getnames())
 glyphset=f.getGlyphSet();geometry=[]
 for cp,g in sorted(f.getBestCmap().items()):
  if 0x980<=cp<=0x9ff:
   pen=DecomposingRecordingPen(glyphset);glyphset[g].draw(pen);geometry.append((cp,pen.value,f['hmtx'].metrics[g]))
 fingerprint=sha(json.dumps(geometry,sort_keys=True).encode());assert fingerprint not in outlines,row['name']+' duplicate Bengali outlines';outlines.add(fingerprint)
 hbfont=hb.Font(hb.Face(data));hb.ot_font_set_funcs(hbfont);samples=[]
 for text in ['কার্যক্রম শিক্ষা শ্রদ্ধা জ্ঞান ক্ষ জ্ঞ শ্র ত্র','কি কী কো কৌ কর্ম র‍্যাব','১২৩৪৫৬৭৮৯০','বাংলা Format 2026','বিশ্ব স্বপ্ন স্বাক্ষর ক্লৢ']:
  buf=hb.Buffer();buf.add_str(text);buf.guess_segment_properties();hb.shape(hbfont,buf)
  missing=sorted(set(c for c in text if ord(c) not in f.getBestCmap() and not c.isspace() and unicodedata.category(c)!='Cf'));bnmissing=[c for c in missing if '\u0980'<=c<='\u09ff']
  notdef=sum(i.codepoint==0 for i in buf.glyph_infos)
  if len(samples)<3:assert notdef==0,(row['name'],text)
  # Mixed Latin fallback is disclosed; unsupported Bengali glyphs are never described as fully supported.
  samples.append({'text':text,'glyphs':len(buf.glyph_infos),'notdefGlyphs':notdef,'missingCharacters':missing,'missingBengali':bnmissing,'advanceUnits':sum(p.x_advance for p in buf.glyph_positions)})
 huge=[g for g,(advance,_) in f['hmtx'].metrics.items() if advance>f['head'].unitsPerEm*4]
 results.append({'family':row['name'],'binaryZipLicenseAndSource':'PASS','previewCmapMetricsLayoutAndAxes':'PASS','bengaliOutlineFingerprint':fingerprint,'specimens':samples,'unusualAdvanceGlyphs':huge,'unitsPerEm':f['head'].unitsPerEm})
out=root/'reports/font-expansion-2026-11-11';out.mkdir(exist_ok=True)
(out/'font-validation.json').write_text(json.dumps({'validator':'fontTools + uharfbuzz '+hb.__version__,'additions':len(results),'results':results},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps([{'family':r['family'],'missingBengali':sorted(set(c for s in r['specimens'] for c in s['missingBengali'])),'unusualAdvanceGlyphs':r['unusualAdvanceGlyphs']} for r in results],ensure_ascii=True))

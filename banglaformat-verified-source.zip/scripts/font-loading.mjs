export const textFontPreloads='<link rel="preload" href="/assets/fonts/noto-sans-bengali-web-bengali.woff2" as="font" type="font/woff2" crossorigin><link rel="preload" href="/assets/fonts/noto-sans-bengali-web-latin.woff2" as="font" type="font/woff2" crossorigin>';
export function optimizeTextFontLoading(html){
 html=html.replace('<script src="/assets/js/main.js"></script>','<script src="/assets/js/main.js" defer></script>');
 html=html.replace(/<link\b[^>]*href="https:\/\/fonts\.(?:googleapis|gstatic)\.com[^>]*>\s*/g,'');
 if(html.includes('href="/assets/css/style.css"')&&!html.includes('href="/assets/fonts/noto-sans-bengali-web-bengali.woff2"'))html=html.replace('</head>',textFontPreloads+'</head>');
 return html;
}

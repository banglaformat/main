import {readdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

export function normalizePageUrls(text,routes){
  // Exact known page paths only. Never rewrite asset directories or external hosts.
  return text.replace(/(?:https?:\/\/[^\s"'<>`?#\\]+|\/[^\s"'<>`?#\\]*)(?=[?#\s"'<>`]|$)/g,token=>{
    if(token.startsWith('http')){
      let u;try{u=new URL(token);}catch{return token;}
      if(u.origin!=='https://banglaformat.co')return token;
      if(u.pathname!=='/'&&u.pathname.endsWith('/')&&routes.has(u.pathname.slice(0,-1)))return token.slice(0,-1);
    }else if(!token.startsWith('//')&&token!=='/'&&token.endsWith('/')&&routes.has(token.slice(0,-1)))return token.slice(0,-1);
    return token;
  });
}
export async function finalizePages(root=path.resolve('dist')){
  async function walk(d){let out=[];for(const e of await readdir(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())out.push(...await walk(p));else out.push(p);}return out;}
  const files=await walk(root);
  const pages=files.filter(p=>path.basename(p)==='index.html');
  const routes=new Set(pages.map(p=>'/'+path.relative(root,path.dirname(p)).replaceAll(path.sep,'/')));
  for(const file of files.filter(p=>/\.(?:html|xml|txt|json)$/.test(p))){
    const original=await readFile(file,'utf8'),updated=normalizePageUrls(original,routes);
    if(updated!==original)await writeFile(file,updated);
  }
  for(const page of pages){
    if(page===path.join(root,'index.html'))continue;
    // GitHub Pages resolves /name via name.html before directory fallback.
    // Preserve directory/index.html for existing inbound links; both share canonical metadata.
    await writeFile(path.dirname(page)+'.html',await readFile(page));
  }
  console.log(`PASS slashless build: ${routes.size} canonical routes, ${pages.length-1} clean-URL HTML files, old directory pages preserved.`);
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))await finalizePages();

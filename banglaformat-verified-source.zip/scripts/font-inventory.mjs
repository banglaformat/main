import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fonts} from './font-catalog.mjs';
const records=[];
for(const f of fonts.filter(f=>f.file)){
 const b=await readFile('assets/fonts/'+f.file),tables={};for(let i=0;i<b.readUInt16BE(4);i++){const p=12+i*16;tables[b.toString('ascii',p,p+4)]={offset:b.readUInt32BE(p+8),length:b.readUInt32BE(p+12)};}
 const start=tables.name.offset,count=b.readUInt16BE(start+2),strings=start+b.readUInt16BE(start+4),names={};
 for(let i=0;i<count;i++){const p=start+6+i*12,platform=b.readUInt16BE(p),id=b.readUInt16BE(p+6),length=b.readUInt16BE(p+8),offset=b.readUInt16BE(p+10);if(![0,1,2,5,13,14].includes(id)||![0,3].includes(platform))continue;const bytes=Buffer.from(b.subarray(strings+offset,strings+offset+length));if(bytes.length%2===0)names[id]=bytes.swap16().toString('utf16le');}
 records.push({family:f.name,file:f.file,sha256:createHash('sha256').update(b).digest('hex'),bytes:b.length,fontNames:names,embeddingFsType:tables['OS/2']?b.readUInt16BE(tables['OS/2'].offset+8):null,licenseFile:f.license,provenance:f.slug.startsWith('noto-')?'Inherited source archive: fonts-noto-core distribution, included copyright/OFL notice. Binary metadata recorded here.':'Fetched from official google/fonts repository; see upstream-provenance.json.'});
}
await writeFile('reports/font-inventory.json',JSON.stringify(records,null,2)+'\n');console.log('Recorded four font binaries, internal names, licenses, embedding flags and SHA-256.');

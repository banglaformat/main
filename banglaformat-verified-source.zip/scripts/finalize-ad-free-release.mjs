// Compatibility entry point: the current publisher configuration supersedes the ad-free release.
import './implement-current-adsense.mjs';

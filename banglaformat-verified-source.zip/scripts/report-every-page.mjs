import {readFile,writeFile} from 'node:fs/promises';
const dir='reports/every-page-audit-2026-11-11',rows=JSON.parse(await readFile(dir+'/pages.json','utf8')),fixes=JSON.parse(await readFile(dir+'/fixes.json','utf8'));
const recommendations=r=>{
 if(r.kind==='error')return 'Correct noindex; test a genuinely missing URL for HTTP 404. Direct /404.html may return 200.';
 if(r.kind==='policy')return 'Keep ownership, contact and policy statements accurate. Schema is optional for this page type.';
 if(r.kind==='hub')return 'Keep descriptive category links; evaluate query/page performance after publication.';
 if(r.kind==='tool')return 'Keep encoding limitations visible; expand converter accuracy only with meaningful fixtures.';
 if(r.kind==='font')return 'Keep publisher, exact font version and license evidence current; test preview and downloaded file.';
 if(r.sourceLinks.length===0)return 'Source externally verifiable rules/claims where applicable; original illustrative samples need clear labeling, not fabricated citations.';
 return 'Keep cited institution-specific rules dated and scoped; verify sources again before using time-sensitive requirements.';
};
const table=rows.map(r=>{const fixed=fixes.find(f=>'/'+f.file.replace('index.html','')===r.route);return `| ${r.route} | ${r.kind} | ${r.errors.length?'Review':'Pass'} | ${fixed?.faqUpdated?'FAQ synchronized':fixed?'Repeated sentence removed':'No new technical fix'} | ${recommendations(r)} |`;}).join('\n');
const text=`# Every-page SEO and answer-discovery audit

Prepared 11 November 2026. Covers all ${rows.length} deployed HTML files: 58 canonical pages and the noindex 404 document. Local project and served-build audit; no deployment was performed.

## Result

All pages were parsed individually, compared with their source files and fetched from the local production preview. No unresolved errors remain in the implemented technical checks. Nine existing FAQ schema blocks were synchronized with visible questions and answers; a duplicated sentence was removed from the converter. Changes are recorded in fixes.json with exact pre/post hashes. The original page layout and samples were preserved.

The audit covers unique titles, descriptions, canonical/sitemap agreement, H1 and main landmarks, duplicate IDs, page HTTP responses, source/build agreement, JSON-LD parsing, visible FAQ parity, breadcrumb fields, Open Graph URLs, internal links/fragments, copy targets, reachability, robots/reference-file synchronization, ad-code absence and the existing release protections. Other release tests cover matching TXT downloads and font files/licenses. Structured-data absence on a policy page is not itself an error; an FAQ or special AI schema is not required on every page.

The converter has one H1 above its main landmark; it was not missing a page heading. The initial audit was corrected to check the whole document. The direct /404.html file returns 200 in this preview, while real nonexistent URLs correctly return 404 and the error document is noindex.

## AEO GEO and LLMO assessment

Content is available as static HTML, with descriptive navigation and clear document-task distinctions. Sources and exact institutional limitations are retained on newly researched guides. The page inventory records headings, opening paragraphs, source links, visible FAQ entries and schema types separately for every page. These are observable features, not numerical AI-visibility scores.

Google's current guidance says ordinary SEO foundations apply to AI search, and there is no special required AI markup: https://developers.google.com/search/docs/appearance/ai-features . This audit therefore checks readable content, discoverability and accurate visible/schema representation. It does not promise rich results, indexing or citations. Existing llms.txt is a reference aid, not proof of eligibility or a ranking signal.

Older articles without external references remain editorial opportunities where they assert institutional rules, software behavior or hiring outcomes. Original template wording does not require an invented citation. The recommendation column below is deliberately separate from technical pass status. No assertion is made that every factual sentence has received independent expert verification, or that all external destinations remain available.

## Page-by-page register

| Page | Type | Technical checks | Change in this pass | Editorial or operational follow-up |
|---|---|---|---|---|
${table}

## Verification limits

Technical results describe this local release and local HTTP server. Production DNS/redirects, CDN or host headers, Google/Bing indexing, field Core Web Vitals, mobile rendering of every page, and AI citations require live checks. A prior final browser check was blocked by automatic approval review's usage limit; no all-page rendered-browser claim is made. Review pages.json for raw evidence, EDITORIAL-INVENTORY.md for extracted page outlines, and summary.json for unresolved implemented-check findings.

Publish only the final deployment ZIP, then inspect priority URLs in the existing Search Console/Bing properties and measure complete equivalent periods. Do not infer keyword cannibalization or ranking improvement from local pass status.
`;
await writeFile(dir+'/PAGE-BY-PAGE-AUDIT.md',text);console.log(`Wrote ${rows.length} page-level decisions and editorial follow-ups.`);

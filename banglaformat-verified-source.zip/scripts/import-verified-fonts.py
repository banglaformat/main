"""Package the audited local upstream downloads. Never fetch or substitute a font silently.
Input staging: tmp/font-research; output: catalog, source register, ZIPs and lossless previews.
"""
from pathlib import Path
import sys,json,hashlib,zipfile,tarfile,io,re
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp/font-tools'))
from fontTools.ttLib import TTFont
stage=ROOT/'tmp/font-research'; assets=ROOT/'assets/fonts'
selected=json.loads((stage/'selected.json').read_text(encoding='utf-8'))
inspection=json.loads((stage/'inspection.json').read_text(encoding='utf-8'))
hashof=lambda b:hashlib.sha256(b).hexdigest()
def names(f,i):return list(dict.fromkeys(x.toUnicode() for x in f['name'].names if x.nameID==i))
def zipwrite(z,n,b):
 info=zipfile.ZipInfo(n,(2026,11,11,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
register=[];catalog=[];previews=[]
for c in selected:
 slug=c['slug'];u=c['upstream']; extra={}; source_material=None
 if u in ['tirobangla','balooda2','atma','galada','mina','alkatra']:
  folder=stage/u; paths=list(folder.glob('*.ttf')); original=next((p for p in paths if p.name.endswith('-Regular.ttf')),paths[0]);data=original.read_bytes();original_name=original.name
  license_body=(folder/'OFL.txt').read_text(encoding='utf-8');license_id='OFL-1.1';source=f'https://github.com/google/fonts/tree/main/ofl/{u}'
  binary_url=f'https://raw.githubusercontent.com/google/fonts/main/ofl/{u}/{original_name}'
  author=re.search(r'designer: "([^"]+)"',(folder/'METADATA.pb').read_text(encoding='utf-8')).group(1)
  evidence='Google Fonts catalog inclusion; no keyword search-volume measurement.'
 elif u in ['mukti','mitra']:
  original_name='mukti.otf' if u=='mukti' else 'MitraMono.ttf';data=(stage/original_name).read_bytes();license_id='GPL-3.0-or-later WITH Font-exception-2.0'
  archive=stage/('mukti-3.5-source.tar.gz' if u=='mukti' else 'mitramono-source.tar.gz');source_material=archive.read_bytes()
  with tarfile.open(archive) as t:
   lic=next(n for n in t.getnames() if n.endswith('/LICENCE') or n.endswith('/LICENSE'));license_body=t.extractfile(lic).read().decode('utf-8')
   sfd=next(n for n in t.getnames() if n.endswith('/mukti.sfd') or n.endswith('/mitramono.sfd'));sfd_text=t.extractfile(sfd).read().decode('utf-8',errors='replace')
   expected='3.5.0' if u=='mukti' else '1.0.2';assert expected in re.search(r'^Version: (.+)$',sfd_text,re.M).group(1)
  source='https://www.nongnu.org/freebangfont/downloads.html';binary_url='https://www.nongnu.org/freebangfont/dl/'+original_name;author='Dr Anirban Mitra · Mukta Bangla Font Project' if u=='mukti' else 'Dr Anirban Mitra'
  extra['source.tar.gz']=source_material;evidence='Primary Free Bangla Fonts project listing; archival/specialist usefulness, not measured search demand.'
 else:
  package=stage/(u+'.package');record=next(a for a in inspection if a['package']==u+'.package')
  chosen=next((f for f in record['fonts'] if f['names']['2']==['Regular']),record['fonts'][0]);original_name=chosen['file']
  with zipfile.ZipFile(package) as z:
   data=z.read(original_name)
   for n in z.namelist():
    if not n.lower().endswith(('.ttf','.otf')) and not n.endswith('/'):
     assert '..' not in Path(n).parts;extra['upstream/'+n]=z.read(n)
  source=f'https://ekushey.org/font/{u}/';html=(stage/(u+'.html')).read_text(encoding='utf-8');binary_url='https://ekushey.org'+re.search(r'href="(/download-font\?cp-ekushey-font-id=\d+)"',html).group(1)
  license_id='OFL-1.0';license_body=(stage/'OFL-1.0.txt').read_text(encoding='utf-8');author=' · '.join(chosen['names']['9'] or chosen['names']['8'] or ['Ekushey contributors'])
  if u=='ekusher-alo':author='Shah Alam Alo · Md. Alinur Islam · Niladri Shekhar Bala'
  if u=='ekushey-lohit':author='Automatic Control Equipments, Pune · Ekushey contributors · Alamgir Mohammed · Ershadul Haq'
  evidence='Primary Ekushey archive listing; no current search-volume or popularity claim.'
 font=TTFont(io.BytesIO(data),recalcTimestamp=False);embedded='\n'.join(names(font,0)+names(font,13))
 assert font['OS/2'].fsType & 2 == 0,slug+' restricted embedding'
 assert c['name'].strip() in [n.strip() for n in names(font,1)+names(font,16)],(slug,names(font,1))
 assert ('Open Font License, Version 1.0' in embedded if license_id=='OFL-1.0' else ('OPEN FONT LICENSE' in license_body if license_id=='OFL-1.1' else 'GNU GPL' in embedded))
 file=slug+Path(original_name).suffix.lower();(assets/file).write_bytes(data)
 version='; '.join(names(font,5));cmap=font.getBestCmap();axes=[{'tag':a.axisTag,'min':a.minValue,'default':a.defaultValue,'max':a.maxValue} for a in font['fvar'].axes] if 'fvar' in font else []
 weight=next((f"{a['min']:g} {a['max']:g}" for a in axes if a['tag']=='wght'),'400')
 notice=f"{c['name']}\nAuthor/project: {author}\nSource: {source}\nOriginal file: {original_name}\nVersion: {version}\nOriginal SHA-256: {hashof(data)}\nLicense: {license_id}\n\nEmbedded copyright and license notices (verbatim):\n{embedded}\n\n"
 notice+='The original font binary is unchanged. The WOFF2 preview uses lossless compression. '
 if license_id=='OFL-1.0':
  preview_family='BF Preview '+c['name'];notice+=f'The preview derivative is renamed {preview_family} under OFL 1.0; its glyphs, metrics, character map and layout tables are unchanged. '
  for i,value in [(1,preview_family),(3,preview_family+' Preview 2026'),(4,preview_family),(6,preview_family.replace(' ','')),(16,preview_family)]:
   for record in font['name'].names:
    if record.nameID==i:record.string=value.encode(record.getEncoding(),errors='replace')
  font['name'].setName('Losslessly compressed and renamed for browser preview by Bangla Format, 2026-11-11. Original font glyphs and layout are unchanged.',10,3,1,0x409)
 notice+='Downloads retain the original family name. No endorsement by the authors is implied.\n\n'
 license_file=slug+'-LICENSE.txt';(assets/license_file).write_text(notice+license_body,encoding='utf-8',newline='\n')
 preview=file.rsplit('.',1)[0]+'.preview.woff2';font.flavor='woff2';font.save(assets/preview);check=TTFont(assets/preview)
 assert font.getBestCmap()==check.getBestCmap();assert font.getGlyphOrder()==check.getGlyphOrder();assert font['hmtx'].metrics==check['hmtx'].metrics
 for tag in ['GSUB','GPOS']:
  if tag in font:assert font[tag].compile(font)==check[tag].compile(check)
 if axes:assert [(a.axisTag,a.minValue,a.defaultValue,a.maxValue) for a in font['fvar'].axes]==[(a.axisTag,a.minValue,a.defaultValue,a.maxValue) for a in check['fvar'].axes]
 pb=(assets/preview).read_bytes();assert len(pb)<len(data)
 readme=f"{c['name']} — original {original_name}\n{source}\nRead {license_file} before use or redistribution.\nEncoding: Unicode Bengali"+(' with additional legacy ISCII mappings' if u=='mitra' else '')+".\nOnly this selected style is bundled; weights do not count as families.\n"
 if source_material:readme+='Corresponding editable source, build script and license are supplied in source.tar.gz. GPL 3 or later is the selected redistribution license. Font embedding exception retained.\n'
 with zipfile.ZipFile(assets/(slug+'.zip'),'w') as z:
  zipwrite(z,original_name,data);zipwrite(z,license_file,(notice+license_body).encode('utf-8'));zipwrite(z,'README.txt',readme.encode('utf-8'))
  for n,b in extra.items():zipwrite(z,n,b)
 with zipfile.ZipFile(assets/(slug+'.zip')) as z:
  assert z.read(original_name)==data;assert z.testzip() is None
 zip_bytes=(assets/(slug+'.zip')).read_bytes()
 row={**c,'author':author,'file':file,'originalFile':original_name,'previewFile':preview,'license':license_file,'licenseId':license_id,'version':version,'style':('Variable '+weight if axes else 'Book 400' if u=='mukti' else 'Regular 400'),'weightRange':weight,'source':source,'binarySource':binary_url,'encoding':'Unicode Bengali'+(' + legacy ISCII mappings' if u=='mitra' else ''),'format':Path(file).suffix[1:].upper(),'demandEvidence':evidence,'sha256':hashof(data),'zipSha256':hashof(zip_bytes),'previewSha256':hashof(pb),'bengaliCodepoints':sum(0x980<=cp<=0x9ff for cp in cmap),'latinLetters':sum(cp in cmap for cp in range(65,91)),'axes':axes,'embeddingFlags':font['OS/2'].fsType,'reviewed':'2026-11-11'}
 catalog.append(row);register.append({**row,'embeddedNames':{str(i):names(TTFont(io.BytesIO(data)),i) for i in [0,1,2,5,8,9,13,14,16]},'packageContents':list(zipfile.ZipFile(assets/(slug+'.zip')).namelist()),'sourceSha256':hashof(source_material) if source_material else None,'obligations':'Keep copyright, license and attribution; no font-only sale; rename modified font under OFL 1.0.' if license_id=='OFL-1.0' else 'Keep copyright, license and applicable reserved-name terms; no font-only sale.' if license_id=='OFL-1.1' else 'Keep GPL, notices, embedding exception and corresponding source; provide modifications under GPL.'})
 previews.append({'file':preview,'original':file,'originalBytes':len(data),'bytes':len(pb),'sha256':hashof(pb),'license':license_file,'cmapGlyphsMetricsAndVariableAxes':'PASS','GSUBAndGPOS':'PASS'})
(ROOT/'scripts/font-additions.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(assets/'font-source-register.json').write_text(json.dumps(register,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
old=json.loads((assets/'preview-provenance.json').read_text());old=[p for p in old if p['original'] not in [f['file'] for f in catalog]]
(assets/'preview-provenance.json').write_text(json.dumps(old+previews,indent=2)+'\n')
print(f'Verified and packaged {len(catalog)} unique additions; no unverified candidate substituted.')

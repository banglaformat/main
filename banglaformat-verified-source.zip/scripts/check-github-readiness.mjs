import {readFile,writeFile,mkdir,cp,stat,readdir} from 'node:fs/promises';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const root=process.cwd(),out=path.resolve('tmp/github-readiness-source');
await mkdir(out,{recursive:true});
const dirs=['.github','about','academic-applications','assets','bangla-fonts','contact','converters','cv-resume-templates','disclaimer','editorial-policy','office-letters-notices','privacy-policy','professional-emails','terms','guides','scripts','tests'];
for(const dir of dirs)await cp(dir,path.join(out,dir),{recursive:true});
for(const name of ['ads.txt','index.html','404.html','CNAME','.nojekyll','_headers','robots.txt','sitemap.xml','site.webmanifest','llms.txt','package.json','.gitignore','DEPLOYMENT.md',...(await readdir(root)).filter(f=>/^favicon.*\.(png|svg|ico)$/.test(f))])await cp(name,path.join(out,name));
await mkdir(path.join(out,'public'),{recursive:true});for(const name of ['ads.txt','robots.txt','sitemap.xml','llms.txt'])await cp('public/'+name,path.join(out,'public',name));
// Copy only validation fixtures, not private research exports or downloaded repository copies.
const manifestFiles=['reports/original-route-hashes.json','reports/content-implementation-2026-11-11/approved-changes.json','reports/final-audit-2026-11-11/changes.json'];
const fixtures=new Set(manifestFiles);
for(const file of manifestFiles.slice(1)){const m=JSON.parse(await readFile(file,'utf8'));for(const change of m.changes)fixtures.add(change.snapshot);}
for(const file of fixtures){await mkdir(path.dirname(path.join(out,file)),{recursive:true});await cp(file,path.join(out,file));}
const result=spawnSync(process.execPath,['scripts/build-static.mjs'],{cwd:out,encoding:'utf8'});if(result.status!==0)throw Error(result.stderr||result.stdout);
const check=spawnSync(process.execPath,['tests/release.test.mjs'],{cwd:out,encoding:'utf8'});if(check.status!==0)throw Error(check.stderr||check.stdout);
const converter=spawnSync(process.execPath,['tests/bijoy-converter.test.cjs'],{cwd:out,encoding:'utf8'});if(converter.status!==0)throw Error(converter.stderr||converter.stdout);
const report={cleanSourceBuild:'PASS',releaseChecks:'PASS',converterChecks:'PASS',nodeVersion:process.version,sourceDirectory:out,requiredFixtureFiles:fixtures.size,productionZIPIsSourceProject:false,liveGitHubSettingsVerified:false,aiStudioImportVerified:false,notes:'Local clean-source simulation without node_modules or dependency install. Windows execution; GitHub Linux runner not executed.'};
await mkdir('reports/github-ai-studio-readiness-2026-11-11',{recursive:true});await writeFile('reports/github-ai-studio-readiness-2026-11-11/verification.json',JSON.stringify(report,null,2)+'\n');console.log(check.stdout+converter.stdout+JSON.stringify(report,null,2));


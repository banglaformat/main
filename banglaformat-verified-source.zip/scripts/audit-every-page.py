"""Audit every deployed HTML page using the standard library, without browser assumptions."""
from html.parser import HTMLParser
from pathlib import Path
from collections import Counter, deque
from urllib.parse import urljoin, urlparse, unquote
import json, re, hashlib
import urllib.request, urllib.error

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'reports/every-page-audit-2026-11-11'
OUT.mkdir(parents=True,exist_ok=True)
class Node:
    def __init__(self,tag='',attrs=None,parent=None):
        self.tag,self.attrs,self.parent,self.children=tag,dict(attrs or []),parent,[]
    def text(self):
        return ''.join(c if isinstance(c,str) else ('' if c.tag in ('script','style','noscript') else c.text()) for c in self.children)
    def all(self,tag=None):
        found=[]
        for c in self.children:
            if isinstance(c,Node):
                if tag is None or c.tag==tag:found.append(c)
                found+=c.all(tag)
        return found
class Parser(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.root=Node();self.current=self.root
    def handle_starttag(self,tag,attrs):
        n=Node(tag,attrs,self.current);self.current.children.append(n)
        if tag not in ('area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'):self.current=n
    def handle_startendtag(self,tag,attrs):self.handle_starttag(tag,attrs);self.handle_endtag(tag)
    def handle_endtag(self,tag):
        n=self.current
        while n.parent and n.tag!=tag:n=n.parent
        if n.tag==tag:self.current=n.parent
    def handle_data(self,data):self.current.children.append(data)
def norm(s):return re.sub(r'\s+',' ',s).strip()
def nodes(o):
    if isinstance(o,dict):
        yield o
        for v in o.values():yield from nodes(v)
    elif isinstance(o,list):
        for v in o:yield from nodes(v)
rows=[];inventory=[]
for file in sorted((ROOT/'dist').rglob('*.html')):
    rel=file.relative_to(ROOT/'dist').as_posix();route='/'+rel.removesuffix('index.html');url='https://banglaformat.co'+route
    html=file.read_text(encoding='utf-8-sig');p=Parser();p.feed(html);root=p.root
    mains=root.all('main');main=mains[0] if mains else root
    meta={n.attrs.get('name',n.attrs.get('property','')):n.attrs.get('content','') for n in root.all('meta')}
    canonical=[n.attrs.get('href') for n in root.all('link') if n.attrs.get('rel')=='canonical']
    headings=[{'level':int(n.tag[1]),'text':norm(n.text())} for n in main.all() if re.fullmatch('h[1-6]',n.tag)]
    title=norm(root.all('title')[0].text()) if root.all('title') else ''
    ids=[n.attrs['id'] for n in root.all() if 'id' in n.attrs];duplicate_ids=[k for k,v in Counter(ids).items() if v>1]
    errors=[];review=[];schemas=[]
    if len(mains)!=1:errors.append('Expected one main landmark')
    if len(root.all('h1'))!=1:errors.append('Expected one page H1')
    if not title or not meta.get('description'):errors.append('Missing title/description')
    if duplicate_ids:errors.append('Duplicate IDs: '+', '.join(duplicate_ids))
    if route!='/404.html' and canonical!=[url]:errors.append('Canonical mismatch')
    if route!='/404.html' and re.search(r'noindex|nosnippet',meta.get('robots',''),re.I):errors.append('Search/snippet blocked')
    if route=='/404.html' and 'noindex' not in meta.get('robots',''):errors.append('404 should not index')
    for script in root.all('script'):
        if script.attrs.get('type')=='application/ld+json':
            raw=''.join(c for c in script.children if isinstance(c,str))
            try:schemas.append(json.loads(raw))
            except Exception as e:errors.append('Invalid JSON-LD: '+str(e))
    visible=norm(main.text());all_schema=[n for s in schemas for n in nodes(s)]
    for n in all_schema:
        if n.get('@type')=='Question':
            answer=n.get('acceptedAnswer',{}).get('text','');a=Parser();a.feed(answer)
            if norm(n.get('name','')) not in visible:review.append('FAQ question differs from visible text: '+n.get('name',''))
            if norm(a.root.text()) not in visible:review.append('FAQ answer differs from visible text: '+n.get('name',''))
        if n.get('@type')=='BreadcrumbList':
            items=n.get('itemListElement',[])
            if items and items[-1].get('item')!=url:review.append('Last structured breadcrumb points elsewhere')
    source=ROOT/rel
    if not source.exists() or source.read_bytes()!=file.read_bytes():errors.append('Source/build mismatch')
    links=[n.attrs.get('href','') for n in main.all('a')]
    sources=[x for x in links if x.startswith('https://') and urlparse(x).hostname not in ('banglaformat.co','www.banglaformat.co')]
    images=[n for n in root.all('img') if 'alt' not in n.attrs]
    if images:review.append('Images missing alt: '+str(len(images)))
    try:
        with urllib.request.urlopen('http://127.0.0.1:4173'+route,timeout=10) as r:status=r.status;body=r.read()
    except urllib.error.HTTPError as e:status=e.code;body=e.read()
    except Exception as e:status=None;body=b'';review.append('HTTP unavailable: '+str(e))
    if status is not None and status!=(404 if route=='/404.html' else 200):
        # An explicit /404.html file can be served with 200; real missing routes are tested separately.
        if route!='/404.html':errors.append('Unexpected HTTP status '+str(status))
    if route!='/404.html' and status==200 and body!=file.read_bytes():errors.append('Served body differs from build')
    types=sorted({str(n['@type']) for n in all_schema if '@type'in n})
    kind='error' if route=='/404.html' else 'hub' if route=='/' or len(route.strip('/').split('/'))==1 and route not in ['/about/','/contact/','/privacy-policy/','/terms/','/disclaimer/','/editorial-policy/'] else 'tool' if '/converters/'in route else 'font' if '/bangla-fonts/'in route else 'policy' if route in ['/about/','/contact/','/privacy-policy/','/terms/','/disclaimer/','/editorial-policy/'] else 'guide'
    lead=[norm(n.text()) for n in main.all('p') if norm(n.text())][:2]
    visible_faq=[]
    for detail in main.all('details'):
        summaries=detail.all('summary')
        if not summaries:continue
        question=norm(summaries[0].text())
        answer=norm(''.join(c if isinstance(c,str) else c.text() for c in detail.children if c is not summaries[0]))
        if question and answer:visible_faq.append({'@type':'Question','name':question,'acceptedAnswer':{'@type':'Answer','text':answer}})
    row={'route':route,'file':rel,'kind':kind,'title':title,'description':meta.get('description'),'h1':[norm(n.text()) for n in root.all('h1')],'canonical':canonical,'httpStatus':status,'schemaTypes':types,'duplicateIDs':duplicate_ids,'mainCharacters':len(visible),'sourceLinks':sources,'lead':lead,'headings':headings,'visibleFAQ':visible_faq,'errors':errors,'editorialReview':review}
    rows.append(row)
    inventory.append('## '+route+'\n'+title+'\n'+'\n'.join(lead)+'\n'+'\n'.join('  '+str(h['level'])+' '+h['text'] for h in headings)+'\nReview: '+str(review)+'\n')
(OUT/'pages.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'EDITORIAL-INVENTORY.md').write_text('\n'.join(inventory),encoding='utf-8')
summary={'pages':len(rows),'errors':[{'route':r['route'],'findings':r['errors']} for r in rows if r['errors']],'review':[{'route':r['route'],'findings':r['editorialReview']} for r in rows if r['editorialReview']]}
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=True,indent=2))

import {fontTotals} from './font-catalog.mjs';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import path from 'node:path';
const dirs=['about','academic-applications','bangla-fonts','contact','converters','cv-resume-templates','disclaimer','editorial-policy','office-letters-notices','privacy-policy','professional-emails','terms','guides'];
async function htmlFiles(dir){const files=[];for(const e of await readdir(dir,{withFileTypes:true})){const f=path.join(dir,e.name);if(e.isDirectory())files.push(...await htmlFiles(f));else if(e.name.endsWith('.html'))files.push(f.replaceAll('\\','/'));}return files;}
// Change only category hubs and the homepage; article bodies, metadata and analytics stay intact.
for(const file of ['index.html','academic-applications/index.html','cv-resume-templates/index.html','office-letters-notices/index.html']){
 let html=await readFile(file,'utf8');
 if(file==='index.html')html=html.replace('<a href="/bangla-fonts/">বাংলা ফন্ট</a>','<a href="/bangla-fonts/" class="nav-link">বাংলা ফন্ট</a>');
 if(!html.includes('id="font-discovery"'))html=html.replace('</main>',`<section id="font-discovery" class="container" style="padding-top:32px;padding-bottom:32px"><h2>নথির জন্য বাংলা ফন্ট বেছে নিন</h2><p>সিভি, আবেদনপত্র ও অফিস নোটিশে নিজের লেখা দিয়ে ফন্ট পরীক্ষা করুন। <a href="/bangla-fonts/">Bangla font সংগ্রহ, প্রিভিউ ও ডাউনলোড</a> · <a href="/guides/install-bangla-font/">ফন্ট ইনস্টল গাইড</a> · <a href="/guides/bangla-font-fix/">Word ও PDF-এ বাংলা ঠিক করার নিয়ম</a>।</p></section>\n</main>`);
 await writeFile(file,html);
}
const old=await readFile('sitemap.xml','utf8');
const dates=new Map([...old.matchAll(/<url>\s*<loc>([^<]+)<\/loc>\s*<lastmod>([^<]+)<\/lastmod>/g)].map(m=>[m[1],m[2]]));
const files=['index.html',...(await Promise.all(dirs.map(htmlFiles))).flat()];
const routes=files.map(f=>'/'+f.replace(/index\.html$/,'')).sort();
const xml=`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${routes.map(route=>{const url='https://banglaformat.co'+route;const changed=/^\/(bangla-fonts|guides)\//.test(route)||['/','/academic-applications/','/cv-resume-templates/','/office-letters-notices/'].includes(route);return `  <url><loc>${url}</loc><lastmod>${changed?'2026-11-11':dates.get(url)||'2026-10-13'}</lastmod></url>`;}).join('\n')}\n</urlset>\n`;
await writeFile('sitemap.xml',xml);await writeFile('public/sitemap.xml',xml);
let llms=await readFile('llms.txt','utf8');
if(!llms.includes('## Bangla Fonts & Typography'))llms+='\n\n## Bangla Fonts & Typography\n\n- [Bangla Font — বাংলা ফন্ট](https://banglaformat.co/bangla-fonts/): Seven curated families, four licensed download packages, live Unicode text preview and comparison.\n- [Install Bangla fonts](https://banglaformat.co/guides/install-bangla-font/): Windows, macOS, Word and mobile installation guidance.\n- [Fix Bangla text in Word and PDF](https://banglaformat.co/guides/bangla-font-fix/): Encoding, shaping, font loading and PDF troubleshooting.\n- [Bijoy ↔ Unicode converter](https://banglaformat.co/converters/bijoy-to-unicode/): Browser-local conversion with limited SutonnyMJ mappings. Mixed English/legacy text requires manual separation; uncommon glyphs may be lossy.\n\nFonts retain their creators’ ownership. Noto Sans Bengali, Noto Serif Bengali, Hind Siliguri and Anek Bangla packages include SIL OFL 1.1 notices. Other families link to publishers; no implied redistribution permission.\n';
llms=llms.replace(/Seven curated families, four licensed download packages/,`${fontTotals.families} curated families, ${fontTotals.downloads} licensed download packages`).replace(/Fonts retain their creators’ ownership\.[^\n]+/,`Fonts retain their creators’ ownership. ${fontTotals.downloads} local download packages include their applicable OFL or GPL notices and required source materials; three other families link to publishers. Availability is not evidence of search volume.`);
await writeFile('llms.txt',llms);await writeFile('public/llms.txt',llms);
await writeFile('public/robots.txt',await readFile('robots.txt','utf8'));
// Repair existing table-of-contents links without rewriting article content.
for(const file of ['cv-resume-templates/ats-friendly-cv-basic-rules/index.html','professional-emails/email-subject-line-rules-examples/index.html','professional-emails/leave-request-email-sample/index.html']){
 let text=await readFile(file,'utf8');if(!text.includes('id="faq"'))text=text.replace('<section class="faq-section">','<section class="faq-section" id="faq">');await writeFile(file,text);
}
const packageJson=JSON.parse(await readFile('package.json','utf8'));
packageJson.scripts.build='node scripts/build-static.mjs';
packageJson.scripts.preview='node scripts/serve-static.mjs';
packageJson.scripts['generate:fonts']='node scripts/generate-font-pages.mjs && node scripts/finalize-seo.mjs';
packageJson.scripts.test='node tests/bijoy-converter.test.cjs && node tests/release.test.mjs';
packageJson.scripts['check:release']='npm run build && npm test';
await writeFile('package.json',JSON.stringify(packageJson,null,2)+'\n');
console.log(`Sitemap synchronized: ${routes.length} canonical pages; four hubs linked to font library.`);


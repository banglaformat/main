import {readFileSync} from 'node:fs';
export const editorialEdits=JSON.parse(readFileSync(new URL('./editorial-revisions.json',import.meta.url),'utf8'));
export const editorialRoutes=[...new Set(editorialEdits.map(e=>e.route).filter(r=>r!='/404.html'))];
const escape=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
export const plain=s=>s.replace(/<[^>]+>/g,'').replace(/&(?:amp|quot|apos|nbsp|lt|gt|#39|#34|mdash|ndash);/g,m=>({'&amp;':'&','&quot;':'"','&apos;':"'",'&nbsp;':' ','&lt;':'<','&gt;':'>','&#39;':"'",'&#34;':'"','&mdash;':'—','&ndash;':'–'}[m])).replace(/\s+/g,' ').trim();
export function normalizeEditorialContent(html,route){
 route=route.replace(/index\.html$/,'');if(route!=='/404.html'&&!route.endsWith('/'))route+='/';
 const edits=editorialEdits.filter(e=>e.route===route);
 // Preserve copyable sample text and scripts verbatim while editing surrounding prose.
 html=html.split(/(<script\b[\s\S]*?<\/script>|<div class="template-content"[^>]*>[\s\S]*?<\/div>)/g).map(part=>{
  if(/^<(?:script|div class="template-content")/.test(part))return part;
  part=part.replace(/<a\b([^>]*)>([\s\S]*?)<\/a>/g,(all,attrs,inner)=>{const e=edits.find(e=>/^h[23]$/.test(e.tag)&&plain(inner)===e.before);return e?`<a${attrs}>${escape(e.after)}</a>`:all;});
  return part.replace(/<(p|h[1-3]|li)\b([^>]*)>([\s\S]*?)<\/\1>/g,(all,tag,attrs,inner)=>{
   const match=edits.find(e=>e.tag===tag&&plain(inner)===e.before);
   return match?`<${tag}${attrs}>${escape(match.after)}</${tag}>`:all;
  });
 }).join('');
 const replacements=[
  ['বাংলাদেশের শিক্ষার্থী ও পেশাজীবীদের জন্য প্রমিত বাংলা ডকুমেন্টস, প্রশাসনিক চিঠি ও প্রফেশনাল কমিউনিকেশন বিষয়ে বিশেষজ্ঞ এবং নিয়মিত লেখক।','এই পেজে লেখার নমুনা ও ব্যবহারবিধি সংকলিত আছে। নিজের পরিস্থিতির সঙ্গে মিলিয়ে সম্পাদনা করুন; ভুল পেলে যোগাযোগ পাতায় জানান।'],
  ['Bangla Format-এর প্রতিষ্ঠাতা ও প্রধান সম্পাদক। তিনি বাংলাদেশে প্রাতিষ্ঠানিক যোগাযোগ, করপোরেট ডকুমেন্টেশন এবং বাংলা ভাষা প্রমিতকরণের ওপর কাজ করছেন। প্রতিটি ফরম্যাট ও লেখা তিনি ব্যক্তিগতভাবে পর্যালোচনা করেন।','সাইটে যোগাযোগের নাম Hiam। লেখার নমুনা ও সংশোধনে AI সহায়তা ব্যবহার করা হয়েছে। সব পেজ তাঁর ব্যক্তিগত পর্যালোচনার মাধ্যমে প্রকাশিত হয়েছে বলে দাবি করা হচ্ছে না।'],
  ['✓ শতভাগ প্রমিত বাংলা ভাষা','✓ বাংলা লেখার নমুনা'],
  ['✓ কোনো অপ্রয়োজনীয় পপআপ বা ট্র্যাকার নেই','✓ নমুনা পড়তে অ্যাকাউন্ট লাগে না'],
  ['✓ নিয়মিত হালনাগাদকৃত ফরম্যাট','✓ ভুল জানাতে যোগাযোগের ব্যবস্থা'],
 ];
 for(const [before,after]of replacements)html=html.replaceAll(before,after);
 const heading=edits.find(e=>e.tag==='h1');
 if(heading){
  const title=heading.after+' | Bangla Format';
  html=html.replace(/<title>[\s\S]*?<\/title>/,'<title>'+escape(title)+'</title>');
  html=html.replace(/(<meta\b[^>]*(?:property|name)="(?:og:title|twitter:title)"[^>]*content=")[^"]*(")/g,(_,a,b)=>a+escape(title)+b);
 }
 if(route==='/cv-resume-templates/ats-friendly-cv-basic-rules/'&&!html.includes('id="parser-source"'))html=html.replace('</article>','<section id="parser-source"><h2>Parser-এর সীমা সম্পর্কে উৎস</h2><p><a href="https://support.greenhouse.io/hc/en-us/articles/200989175-Unsuccessful-resume-parse">Greenhouse-এর resume parsing সহায়তা পাতায়</a> টেবিল, কলাম, header/footer ও ছবির কারণে তথ্য পড়তে অসুবিধার উদাহরণ আছে। এটি একটি নির্দিষ্ট ব্যবস্থার নির্দেশনা; সব ATS একইভাবে কাজ করে ধরে নেওয়া যাবে না। উৎস দেখা হয়েছে ১৫ নভেম্বর ২০২৬।</p></section></article>');
 // Keep FAQ text and headline strings consistent with their visible revisions.
 html=html.replace(/(<script\b[^>]*type="application\/ld\+json"[^>]*>)([\s\S]*?)(<\/script>)/g,(all,open,text,close)=>{
  const walk=v=>{if(typeof v==='string'){const e=edits.find(e=>plain(v)===e.before);let s=e?e.after:v;for(const [b,a]of replacements)s=s.replaceAll(b,a);return s;}if(Array.isArray(v))return v.map(walk);if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,walk(x)]));return v;};
  let data=walk(JSON.parse(text));
  if(editorialRoutes.includes(route)){const dates=v=>{if(Array.isArray(v))v.forEach(dates);else if(v&&typeof v==='object'){if(v.dateModified)v.dateModified='2026-11-15';Object.values(v).forEach(dates);}};dates(data);}
  return open+JSON.stringify(data)+close;
 });
 if(editorialRoutes.includes(route))html=html.replace(/আপডেট: (?:১১ নভেম্বর ২০২৬|১৪ নভেম্বর ২০২৬|২০২৬)/g,'আপডেট: ১৫ নভেম্বর ২০২৬');
 if(route==='/editorial-policy/')html=html.replace('সর্বশেষ হালনাগাদ: সেপ্টেম্বর ২০২৬','সর্বশেষ হালনাগাদ: ১৫ নভেম্বর ২০২৬').replace('প্রধান সম্পাদক: Hiam','প্রকাশক: Bangla Format');
 if(route==='/')html=html.replace(/<title>[\s\S]*?<\/title>/,'<title>বাংলা আবেদনপত্র, চিঠি ও ইমেইলের নমুনা | Bangla Format</title>');
 return html;
}

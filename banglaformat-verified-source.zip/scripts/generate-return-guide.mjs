import {readFile,writeFile,mkdir} from 'node:fs/promises';
export const slug='return-to-work-after-leave';
export const title='ছুটি শেষে কাজে যোগদানের আবেদন: বাংলা চিঠি ও ইংরেজি ইমেইল';
export const lead='অনুমোদিত ছুটি শেষে কাজে ফিরেছেন? যোগদানের তারিখ ও আগের ছুটির তথ্য মিলিয়ে ছোট একটি চিঠি বা ইমেইল লিখুন। নতুন চাকরিতে যোগদানের চিঠি থেকে এটি আলাদা।';
export const bangla=`তারিখ: [চিঠি জমার তারিখ]

বরাবর
[দায়িত্বপ্রাপ্ত কর্মকর্তার পদবি]
[প্রতিষ্ঠানের নাম]

বিষয়: ছুটি শেষে কাজে যোগদানের তথ্য অবহিতকরণ।

জনাব/জনাবা,
আমার অনুমোদিত ছুটির সময়কাল ছিল [শুরুর তারিখ] থেকে [শেষ তারিখ] পর্যন্ত। [অনুমোদনপত্র বা ইমেইলের তারিখ ও রেফারেন্স, থাকলে] অনুযায়ী ছুটি ভোগ শেষে আজ [কাজে ফেরার তারিখ] কাজে যোগ দিয়েছি।

অনুগ্রহ করে আমার যোগদানের তথ্য নথিভুক্ত করার অনুরোধ করছি। কোনো নির্ধারিত ফরম বা অতিরিক্ত আনুষ্ঠানিকতা প্রয়োজন হলে জানালে তা সম্পন্ন করব।

ধন্যবাদান্তে,
[নাম]
[পদবি ও বিভাগ]
[কর্মী আইডি, থাকলে]
[স্বাক্ষর, কাগজে জমা দিলে]`;
export const english=`Subject: Return to work after leave — [Name], [Return date]

Dear [Manager's name],

I returned to work today, [return date], following my approved leave from [start date] to [end date]. The leave was approved by [person/department] on [approval date or reference, if available].

Please let me know if I need to complete a joining report or any other return-to-work formalities.

Thank you,
[Name]
[Role and department]
[Employee ID, if used]`;
const esc=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
export async function generateReturnGuide(){
 const route='/office-letters-notices/'+slug+'/',url='https://banglaformat.co'+route;
 const base=await readFile('office-letters-notices/release-letter-request/index.html','utf8');
 const sample=(key,heading,text)=>`<section aria-labelledby="${key}-heading"><h2 id="${key}-heading">${heading}</h2><div class="template-box"><div class="template-header"><span class="template-title">বন্ধনীর তথ্য বদলান; যে বাক্য সত্য নয় তা বাদ দিন</span><button type="button" class="btn btn-sm btn-copy" data-copy-target="${slug}-${key}" aria-label="${heading} কপি করুন">কপি করুন</button></div><div class="template-content" id="${slug}-${key}">${esc(text)}</div></div><p><a href="/assets/downloads/${slug}-${key}.txt" download>${heading} TXT ডাউনলোড</a></p></section>`;
 const body=`<main class="container reading-container"><nav class="breadcrumbs" aria-label="ব্রেডক্রাম্ব"><a href="/">হোম</a><span>/</span><a href="/office-letters-notices/">অফিস লেটার ও নোটিশ</a></nav><header class="post-header"><h1 class="post-title">${title}</h1><p class="page-lead">${lead}</p><p class="post-meta">প্রস্তুত: Bangla Format · ১৬ নভেম্বর ২০২৬</p></header><article class="post-content">
<p>ছুটি শেষ হয়েছে, আপনি অফিসে ফিরেছেন—এই তথ্য জানাতেই নিচের নমুনা। এখানে নতুন নিয়োগ গ্রহণ করছেন না, আবার নতুন করে ছুটিও চাইছেন না। আপনার অফিসে শুধু ইমেইল যথেষ্ট হলে দীর্ঘ দরখাস্তের দরকার নেই। আলাদা joining report চাইলে আগে সেই ফরমটি নিন।</p>
<nav aria-label="নমুনা নির্বাচন"><a href="#${slug}-bangla">বাংলা চিঠি</a> · <a href="#${slug}-english">English email</a> · <a href="#return-date-check">তারিখের উদাহরণ</a></nav>
<h2>কোন পরিস্থিতিতে কোন লেখা?</h2><ul><li><strong>ছুটি শেষে ইতিমধ্যে ফিরেছেন:</strong> আজ কবে যোগ দিলেন, তা লিখুন। নিচের দুটি নমুনা এই পরিস্থিতির জন্য।</li><li><strong>আগামী দিনে ফেরার খবর দিচ্ছেন:</strong> “যোগ দিয়েছি” লিখবেন না। লিখতে পারেন, “অনুমোদিত ছুটি শেষে [তারিখ]-এ কাজে ফেরার কথা রয়েছে।”</li><li><strong>ছুটির আগেই ফিরতে চান বা আরও ছুটি দরকার:</strong> আগে পরিবর্তনের অনুমোদন চান। নিজে থেকে ছুটির হিসাব বদলে গেছে বলে ধরে নেবেন না।</li><li><strong>নতুন চাকরিতে যোগ দিচ্ছেন:</strong> <a href="/office-letters-notices/joining-letter-format/">নতুন চাকরির যোগদানপত্র</a> দেখুন; নিচের ছুটি-পরবর্তী নমুনাটি ব্যবহার করবেন না।</li></ul>
<h2 id="return-date-check">শেষ ছুটির দিন আর যোগদানের দিন মিলিয়ে নিন</h2><p>অনুমোদনের নথি দেখে শুরুর ও শেষের তারিখ লিখুন। কাজে ফিরবেন নিজের নির্ধারিত কর্মদিবসে; ছুটি শেষের পরের দিনই সবার অফিস খোলা থাকবে—এমন নয়।</p>
<table><caption>শুধু তারিখ বোঝানোর কাল্পনিক উদাহরণ</caption><thead><tr><th scope="col">তথ্য</th><th scope="col">এই উদাহরণে</th></tr></thead><tbody><tr><th scope="row">অনুমোদিত ছুটি</th><td>১৭–১৯ নভেম্বর ২০২৬</td></tr><tr><th scope="row">অফিস বন্ধ</th><td>২০–২১ নভেম্বর ২০২৬, ধরা হলো এই অফিসের সাপ্তাহিক বন্ধ</td></tr><tr><th scope="row">নির্ধারিত কর্মদিবসে ফেরা</th><td>২২ নভেম্বর ২০২৬</td></tr></tbody></table>
<p>এই কর্মী ২২ নভেম্বর চিঠি দিলে লিখবেন: “১৭ নভেম্বর থেকে ১৯ নভেম্বর পর্যন্ত অনুমোদিত ছুটি ভোগ শেষে আজ ২২ নভেম্বর ২০২৬ কাজে যোগ দিয়েছি।” এটি কোনো প্রতিষ্ঠানের ছুটির নিয়ম বা হাজিরা গণনার নির্দেশনা নয়। আপনার roster, অনুমোদন ও বাস্তবে ফেরার তারিখ মিলিয়ে নিন।</p>
${sample('bangla','ছুটি শেষে যোগদানের বাংলা চিঠি',bangla)}
${sample('english','Return-to-work email in English',english)}
<h2>পাঠানোর আগে যে চারটি বিষয় দেখবেন</h2><ol><li>আজকের তারিখ, অনুমোদিত ছুটির তারিখ ও বাস্তবে কাজে ফেরার তারিখ একই নথির সঙ্গে মেলে কি না। অনুমোদন ছাড়া অনুপস্থিতির বিষয়কে অনুমোদিত ছুটি বলে লিখবেন না।</li><li>কাকে জমা দিতে হবে—ম্যানেজার, HR নাকি নির্ধারিত পোর্টাল—তা নিজের অফিসের নিয়মে দেখুন। সবাইকে CC করার প্রয়োজন নেই।</li><li>চিঠি গ্রহণের প্রমাণ রাখতে চাইলে অফিসের অনুমোদিত পদ্ধতিতে প্রাপ্তিস্বীকার বা ইমেইলের কপি রাখুন। পাঠানো মানেই অফিসের রেকর্ড হালনাগাদ হয়েছে ধরে নেবেন না।</li><li>ছুটির সময় অন্য কেউ কাজ দেখলে চলমান কাজের অবস্থা তাঁর সঙ্গে মিলিয়ে নিন। “সব দায়িত্ব বুঝে নিয়েছি” কথাটি সত্য না হলে যোগ করবেন না।</li></ol>
<h2>অসুস্থতার ছুটি থেকে ফিরলে</h2><p>কোনো ফরম বা নথি প্রয়োজন কি না, নিজের অফিসের প্রক্রিয়া অনুযায়ী জেনে নিন। সবার জন্য fitness certificate বাধ্যতামূলক—এমন নিয়ম এই নমুনা ঘোষণা করছে না। কাজের ব্যবস্থায় সহায়তা প্রয়োজন হলে দায়িত্বপ্রাপ্ত ব্যক্তির সঙ্গে আলাদাভাবে আলোচনা করুন; সাধারণ CC তালিকায় চিকিৎসার বিস্তারিত পাঠাবেন না।</p>
<h2>সাধারণ প্রশ্ন</h2><h3>ছুটি শেষে সবাইকে লিখিত যোগদানপত্র দিতে হয়?</h3><p>সব অফিসে একই প্রক্রিয়া নেই। কোথাও নির্ধারিত ফরম থাকে, কোথাও ম্যানেজারকে ইমেইল বা attendance system-এ তথ্য দেওয়াই প্রযোজ্য হতে পারে। নিজের অফিসের নির্দেশনা অনুসরণ করুন।</p>
<h3>অনুমোদনের স্মারক নম্বর না থাকলে কী লিখব?</h3><p>যে ইমেইল বা অন্য নথিতে ছুটি অনুমোদিত হয়েছে তার তারিখ উল্লেখ করতে পারেন। কোনো নম্বর না থাকলে বানিয়ে লিখবেন না; অপ্রযোজ্য বন্ধনীর অংশটি বাদ দিন। অনুমোদন নিশ্চিত না হলে আগে সেটি পরিষ্কার করুন।</p>
<h3>ইংরেজিতে rejoining না return to work?</h3><p>এই নমুনায় “return to work after leave” লেখা হয়েছে, যাতে ছুটির পর ফেরার বিষয়টি পরিষ্কার হয়। অফিসের নিজস্ব ফরমে “rejoining report” বা অন্য নাম থাকলে সেটিই ব্যবহার করুন।</p>
<section id="downloads"><h2>ডাউনলোড ও মুদ্রণ</h2><p>TXT নমুনা খুলে নিজের তথ্য বসান। পুরো গাইড মুদ্রণ বা PDF হিসেবে সংরক্ষণ করতে ব্রাউজারের print বিকল্প ব্যবহার করতে পারেন; এটি পূরণযোগ্য PDF ফরম নয়।</p><p><a href="/assets/downloads/${slug}-bangla.txt" download>বাংলা TXT</a> · <a href="/assets/downloads/${slug}-english.txt" download>English TXT</a> · <button type="button" class="btn btn-secondary" data-print-guide>গাইড মুদ্রণ করুন</button></p></section>
<h2>সম্পর্কিত গাইড</h2><ul><li><a href="/office-letters-notices/office-leave-application-casual-medical/">অফিসে ছুটির আবেদন</a></li><li><a href="/professional-emails/leave-request-email-sample/">ছুটি চাওয়ার ইমেইল</a></li><li><a href="/office-letters-notices/handover-letter-format/">দায়িত্ব হস্তান্তরের চিঠি</a></li></ul><p>এটি সাধারণ লেখার খসড়া; কোনো প্রতিষ্ঠানের অনুমোদিত ফরম নয়। <a href="/editorial-policy/">সম্পাদনা নীতি</a> দেখুন বা ভুল পেলে <a href="/contact/">যোগাযোগ করুন</a>।</p></article></main>`;
 const schema={'@context':'https://schema.org','@graph':[{'@type':'Article',headline:title,description:lead,inLanguage:'bn-BD',mainEntityOfPage:url,author:{'@type':'Organization',name:'Bangla Format',url:'https://banglaformat.co/'},publisher:{'@type':'Organization',name:'Bangla Format',url:'https://banglaformat.co/'},datePublished:'2026-11-16',dateModified:'2026-11-16'},{'@type':'BreadcrumbList',itemListElement:[['হোম','/'],['অফিস লেটার ও নোটিশ','/office-letters-notices/'],[title,route]].map(([name,r],i)=>({'@type':'ListItem',position:i+1,name,item:'https://banglaformat.co'+r}))}]};
 let html=base.replaceAll('https://banglaformat.co/office-letters-notices/release-letter-request/',url).replace(/<title>[\s\S]*?<\/title>/,'<title>'+title+' | Bangla Format</title>').replace(/(<meta\b[^>]*(?:name="description"|property="og:description"|name="twitter:description")[^>]*content=")[^"]*(")/g,(_,a,b)=>a+esc(lead)+b).replace(/(<meta\b[^>]*(?:property="og:title"|name="twitter:title")[^>]*content=")[^"]*(")/g,(_,a,b)=>a+esc(title+' | Bangla Format')+b).replace(/<script type="application\/ld\+json">[\s\S]*?<\/script>/,'<script type="application/ld+json">'+JSON.stringify(schema)+'</script>').replace(/<main\b[\s\S]*?<\/main>/,body);
 await mkdir('office-letters-notices/'+slug,{recursive:true});await writeFile('office-letters-notices/'+slug+'/index.html',html);
 for(const [key,text]of [['bangla',bangla],['english',english]])await writeFile('assets/downloads/'+slug+'-'+key+'.txt',text+'\n');
 const hub='office-letters-notices/index.html',marker='<!-- return-guide:'+slug+' -->';let h=await readFile(hub,'utf8');if(!h.includes(marker)){h=h.replace('</main>',marker+'<section class="prose"><h2><a href="'+route+'">'+title+'</a></h2><p>'+lead+'</p></section></main>');await writeFile(hub,h);}
 let sitemap=await readFile('sitemap.xml','utf8');if(!sitemap.includes('<loc>'+url+'</loc>'))sitemap=sitemap.replace('</urlset>','<url><loc>'+url+'</loc><lastmod>2026-11-16</lastmod></url>\n</urlset>');for(const f of ['sitemap.xml','public/sitemap.xml'])await writeFile(f,sitemap);
 console.log('Generated one return-to-work guide and two matching text samples.');
}
if(process.argv[1]?.replaceAll('\\','/').endsWith('/generate-return-guide.mjs'))await generateReturnGuide();

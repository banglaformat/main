import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const folder='reports/every-page-audit-2026-11-11';
const rows=JSON.parse(await readFile(folder+'/pages.json','utf8'));
const manifestFile='reports/final-audit-2026-11-11/changes.json',manifest=JSON.parse(await readFile(manifestFile,'utf8'));
await mkdir(folder+'/before',{recursive:true});
const sha=s=>createHash('sha256').update(s).digest('hex'),changes=[];
for(const row of rows){const file=row.file,before=await readFile(file,'utf8');let after=before,faqUpdated=false;
 if(row.editorialReview.some(x=>x.startsWith('FAQ answer differs'))){
  if(!row.visibleFAQ.length)throw Error('No visible FAQ to synchronize: '+file);
  after=after.replace(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g,(block,json)=>{const graph=JSON.parse(json);let changed=false;function visit(o){if(!o||typeof o!=='object')return;if(o['@type']==='FAQPage'){o.mainEntity=row.visibleFAQ;changed=true;}else for(const value of Object.values(o))if(typeof value==='object')Array.isArray(value)?value.forEach(visit):visit(value);}visit(graph);if(changed){faqUpdated=true;return `<script type="application/ld+json">${JSON.stringify(graph).replaceAll('<','\\u003c')}</script>`;}return block;});
 }
 if(file==='converters/bijoy-to-unicode/index.html')after=after.replace('শুধু legacy বাংলা অংশ রূপান্তর করুন; ইংরেজি অংশ আলাদা রাখুন। শুধু legacy বাংলা অংশ রূপান্তর করুন; ইংরেজি অংশ আলাদা রাখুন।','শুধু legacy বাংলা অংশ রূপান্তর করুন; ইংরেজি অংশ আলাদা রাখুন।');
 if(after!==before){const snapshot=folder+'/before/'+file.replaceAll('/','__');await writeFile(snapshot,before);changes.push({file,snapshot,beforeSHA256:sha(before),afterSHA256:sha(after),faqUpdated});let entry=manifest.changes.find(c=>c.file===file);if(!entry){entry={file,snapshot,beforeSHA256:sha(before)};manifest.changes.push(entry);}entry.afterSHA256=sha(after);await writeFile(file,after);}
}
await writeFile(manifestFile,JSON.stringify(manifest,null,2)+'\n');await writeFile(folder+'/fixes.json',JSON.stringify(changes,null,2)+'\n');console.log(`Fixed ${changes.filter(c=>c.faqUpdated).length} FAQ schemas and removed duplicated converter guidance; ${changes.length} pages changed.`);

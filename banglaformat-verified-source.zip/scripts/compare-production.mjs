import {readFile,readdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const dir='reports/production-comparison-2026-11-11',repo=dir+'/repository';
const commit=execFileSync('git',['-C',repo,'rev-parse','HEAD'],{encoding:'utf8'}).trim();
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const original=JSON.parse(await readFile('reports/original-route-hashes.json','utf8'));
const entries=[];async function walk(d){for(const e of await readdir(d,{withFileTypes:true})){if(e.name==='.git'||e.name==='node_modules')continue;const p=path.join(d,e.name);if(e.isDirectory())await walk(p);else entries.push(p);}}await walk(repo);
const rows=[];
for(const p of entries){const rel=path.relative(repo,p).replaceAll('\\','/');const remote=await readFile(p);let local;try{local=await readFile(rel);}catch{rows.push({path:rel,status:'remote-only'});continue;}const same=remote.equals(local),sameText=remote.toString('utf8').replaceAll('\r\n','\n')===local.toString('utf8').replaceAll('\r\n','\n');const baseline=original[rel];rows.push({path:rel,status:same?'identical':sameText?'line-endings-only':'changed',...(baseline?{matchesOriginalUpload:sha(remote)===baseline||sha(remote.toString('utf8').replaceAll('\r\n','\n'))===baseline}:{})});}
const html=rows.filter(r=>r.path.endsWith('.html'));const results={repository:'https://github.com/banglaformat/main',branch:execFileSync('git',['-C',repo,'branch','--show-current'],{encoding:'utf8'}).trim(),commit,comparisonDate:'2026-11-11',summary:{remoteFiles:rows.length,remoteHtml:html.length,remoteHtmlMatchingOriginalUpload:html.filter(r=>r.matchesOriginalUpload).length,changed:rows.filter(r=>r.status==='changed').length,remoteOnly:rows.filter(r=>r.status==='remote-only').length},rows};
await writeFile(dir+'/comparison.json',JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify({commit,...results.summary,htmlNotMatchingOriginal:html.filter(r=>!r.matchesOriginalUpload),changedFiles:rows.filter(r=>r.status==='changed').map(r=>r.path),remoteOnly:rows.filter(r=>r.status==='remote-only').map(r=>r.path)},null,2));

import {mkdir, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const out = new URL('../assets/fonts/', import.meta.url);
await mkdir(out, {recursive:true});
const families = [
 ['hind-siliguri','hindsiliguri','HindSiliguri-Regular.ttf','HindSiliguri-Regular.ttf'],
 ['anek-bangla','anekbangla','AnekBangla[wdth,wght].ttf','AnekBangla-Variable.ttf'],
];
const provenance=[];
for (const [slug,dir,file,name] of families) {
 const base=`https://raw.githubusercontent.com/google/fonts/main/ofl/${dir}/`;
 const url=base+encodeURIComponent(file);
 const response=await fetch(url); if(!response.ok) throw Error(`${response.status} ${url}`);
 const bytes=Buffer.from(await response.arrayBuffer());
 if(!['00010000','4f54544f'].includes(bytes.subarray(0,4).toString('hex'))) throw Error('Invalid font');
 const licenseResponse=await fetch(base+'OFL.txt'); if(!licenseResponse.ok) throw Error('Missing license');
 const license=await licenseResponse.text(); if(!license.includes('SIL OPEN FONT LICENSE')) throw Error('Unexpected license');
 await writeFile(new URL(name,out),bytes); await writeFile(new URL(slug+'-OFL.txt',out),license);
 provenance.push({slug,file:name,source:url,licenseSource:base+'OFL.txt',license:'SIL OFL 1.1',sha256:createHash('sha256').update(bytes).digest('hex'),verified:'2026-11-11'});
}
await writeFile(new URL('upstream-provenance.json',out),JSON.stringify(provenance,null,2)+'\n');
console.log('Installed two upstream font families with licenses and SHA-256 provenance.');

import {readdir, mkdir, cp, readFile, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {normalizeNavigation} from './site-navigation.mjs';
import {normalizeSeoContent, seoUpdatedRoutes} from './seo-content.mjs';
const root=path.resolve(import.meta.dirname,'..');
// Explicit allowlist: never copy public research uploads, node_modules, or source credentials.
const dirs=['about','academic-applications','bangla-fonts','contact','converters','cv-resume-templates','disclaimer','editorial-policy','office-letters-notices','privacy-policy','professional-emails','terms','guides'];
const files=['ads.txt','index.html','404.html','CNAME','.nojekyll','_headers','robots.txt','sitemap.xml','site.webmanifest','llms.txt'];
const out=path.join(root,'dist');
if (out !== path.resolve('dist') || path.dirname(out)!==root || path.basename(out)!=='dist') throw Error('Build must run from the project root; unsafe output path');
await mkdir(out,{recursive:true});
// Refuse stale output rather than mixing old deployments; remove only known build files via clean helper.
const {rm}=await import('node:fs/promises');
for(const entry of await readdir(out)) await rm(path.join(out,entry),{recursive:true,force:true});
for(const dir of dirs) await cp(path.join(root,dir),path.join(out,dir),{recursive:true});
await cp(path.join(root,'assets'),path.join(out,'assets'),{recursive:true,filter:p=>!p.endsWith('.md')&&!p.endsWith('README.txt')});
for(const file of files) await cp(path.join(root,file),path.join(out,file));
for(const file of await readdir(root)) if(/^favicon.*\.(png|svg|ico)$/.test(file)) await cp(path.join(root,file),path.join(out,file));
console.log('Static release built in dist/ with stable asset URLs; research uploads excluded.');

// Normalize only output headers; historical source snapshots and article bodies stay intact.
async function normalizeHeaders(dir) {
  for (const entry of await readdir(dir, {withFileTypes:true})) {
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) await normalizeHeaders(file);
    else if (entry.name.endsWith('.html')) {
      const html = await readFile(file, 'utf8');
      const route = '/' + path.relative(out, file).replaceAll(path.sep, '/');
      await writeFile(file, normalizeSeoContent(normalizeNavigation(html, route), route));
    }
  }
}
await normalizeHeaders(out);

// Keep sitemap copies synchronized and date only substantively edited articles.
for (const file of ['sitemap.xml', 'public/sitemap.xml']) {
  const source = await readFile(path.join(root, file), 'utf8');
  const updated = source.replace(/<url>[\s\S]*?<\/url>/g, block =>
    seoUpdatedRoutes.some(route => block.includes('<loc>https://banglaformat.co'+route+'</loc>'))
      ? block.replace(/<lastmod>[^<]+<\/lastmod>/, '<lastmod>2026-11-14</lastmod>') : block);
  await writeFile(path.join(root, file), updated);
  if (file === 'sitemap.xml') await writeFile(path.join(out, file), updated);
}



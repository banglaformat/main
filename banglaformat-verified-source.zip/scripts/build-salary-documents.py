"""Create editable salary drafts from the same source used by the web guide."""
import json
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

root = Path(__file__).resolve().parents[1]
samples = json.loads((root / 'tmp/salary-samples.json').read_text(encoding='utf-8-sig'))
for sample in samples:
    doc = Document()
    # Remove title-border residue from the bundled base document.
    for element in list(doc.styles.element.iter(qn('w:pBdr'))):
        element.getparent().remove(element)
    for paragraph in list(doc.paragraphs):
        paragraph._element.getparent().remove(paragraph._element)
    section = doc.sections[0]
    section.page_width = Inches(8.27)
    section.page_height = Inches(11.69)
    section.top_margin = section.bottom_margin = Inches(0.7)
    section.left_margin = section.right_margin = Inches(0.8)
    for name in ['Normal', 'Title']:
        style = doc.styles[name]
        style.font.name = 'Nirmala UI'
        style.font.size = Pt(11 if sample['id'].endswith('english') else 12)
        style.font.color.rgb = RGBColor(0, 0, 0)
        rpr = style.element.get_or_add_rPr()
        fonts = rpr.find(qn('w:rFonts'))
        if fonts is None:
            fonts = OxmlElement('w:rFonts')
            rpr.append(fonts)
        for key in ['ascii', 'hAnsi', 'cs', 'eastAsia']:
            fonts.set(qn('w:' + key), 'Nirmala UI')
        size = OxmlElement('w:szCs')
        size.set(qn('w:val'), '24')
        rpr.append(size)
    normal = doc.styles['Normal'].paragraph_format
    normal.space_after = Pt(3)
    normal.line_spacing = 1.08
    title = doc.styles['Title']
    title.font.size = Pt(16)
    title.font.bold = True
    title.paragraph_format.space_after = Pt(8)
    title.paragraph_format.keep_with_next = True
    for line in sample['text'].splitlines():
        p = doc.add_paragraph(line, style='Title' if line in ['বেতন প্রত্যয়নপত্র', 'Salary Certificate'] else 'Normal')
        p.paragraph_format.widow_control = True
    doc.core_properties.title = sample['title']
    doc.core_properties.author = 'Bangla Format'
    doc.core_properties.subject = 'Original illustrative draft requiring employer verification'
    dest = root / 'assets/downloads' / (sample['id'] + '.docx')
    doc.save(dest)
    print(dest.name)

"""Lossless WOFF2 packaging for previews; original TTF downloads remain unchanged."""
from pathlib import Path
import sys,json,hashlib
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tmp/font-tools'))
from fontTools.ttLib import TTFont
items=json.loads((root/'tmp/font-previews.json').read_text(encoding='utf-8'))
results=[]
for item in items:
    source=root/'assets/fonts'/item['file']
    dest=source.with_suffix('.preview.woff2')
    font=TTFont(source,recalcTimestamp=False)
    font.flavor='woff2'
    font.save(dest)
    check=TTFont(dest)
    assert font.getBestCmap()==check.getBestCmap()
    assert font.getGlyphOrder()==check.getGlyphOrder()
    assert font['hmtx'].metrics==check['hmtx'].metrics
    if 'fvar' in font:
        assert [(a.axisTag,a.minValue,a.defaultValue,a.maxValue) for a in font['fvar'].axes]==[(a.axisTag,a.minValue,a.defaultValue,a.maxValue) for a in check['fvar'].axes]
    results.append({'file':dest.name,'original':source.name,'originalBytes':source.stat().st_size,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'license':item['license'],'cmapGlyphsMetricsAndVariableAxes':'PASS'})
(root/'assets/fonts/preview-provenance.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))

// Shared by final cleanup and generators so advertising cannot return on regeneration.
import {optimizeTextFontLoading} from './font-loading.mjs';
import {applyAdsense} from './adsense-config.mjs';
export function cleanFinalHtml(html){
 html=html.replace(/<!--\s*Google AdSense\s*-->\s*/gi,'').replace(/<meta\b[^>]*name=["']google-adsense-account["'][^>]*>\s*/gi,'').replace(/<script\b[^>]*src=["'][^"']*(?:googlesyndication\.com|doubleclick\.net)[^"']*["'][^>]*>[\s\S]*?<\/script>\s*/gi,'').replace(/<ins\b[^>]*class=["'][^"']*adsbygoogle[^"']*["'][^>]*>[\s\S]*?<\/ins>/gi,'').replace(/<script\b[^>]*>\s*\(?adsbygoogle[\s\S]*?<\/script>/gi,'');
 html=html.replace(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g,(block,json)=>{let changed=false;const graph=JSON.parse(json);function visit(o){if(!o||typeof o!=='object')return;for(const [key,value]of Object.entries(o)){if(key==='name'&&typeof value==='string'&&/<[^>]+>/.test(value)){o[key]=value.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();changed=true;}else if(typeof value==='object')Array.isArray(value)?value.forEach(visit):visit(value);}}visit(graph);return changed?`<script type="application/ld+json">${JSON.stringify(graph).replaceAll('<','\\u003c')}</script>`:block;});
 return applyAdsense(optimizeTextFontLoading(html));
}

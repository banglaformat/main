export const applicationSalaryGuides=[{
route:'/professional-emails/job-application-email-sample/',category:'/professional-emails/',categoryName:'প্রফেশনাল ইমেইল',title:'ইমেইলে চাকরির আবেদন: CV পাঠানোর নিয়ম ও ৩টি নমুনা | Bangla Format',h1:'ইমেইলে চাকরির আবেদন: Subject, CV ও ৩টি সম্পূর্ণ নমুনা',description:'চাকরির আবেদন ইমেইল লেখার নিয়ম: ফ্রেশার, অভিজ্ঞ ও ইন্টার্নশিপ প্রার্থীর subject ও body, CV সংযুক্তির চেকলিস্ট এবং job inquiry থেকে পার্থক্য।',lead:'বিজ্ঞাপিত নির্দিষ্ট পদে ইমেইলে আবেদন করতে বিষয়, সংক্ষিপ্ত পরিচয় এবং সঠিক সংযুক্তি একসঙ্গে গুছিয়ে নিন। নিয়োগ বিজ্ঞপ্তির নির্দেশনা এই সাধারণ নমুনার আগে অনুসরণ করুন।',
intro:`<p><strong>চাকরির আবেদন ইমেইলে কী লিখবেন?</strong> কোন পদে আবেদন করছেন, কোথায় বিজ্ঞপ্তি দেখেছেন, নিজের প্রাসঙ্গিক যোগ্যতার সংক্ষিপ্ত প্রমাণ এবং কোন ফাইল সংযুক্ত করেছেন তা লিখুন। বিষয় বা Subject-এ বিজ্ঞপ্তির নির্ধারিত বিন্যাস থাকলে সেটিই দিন।</p><p>এটি নির্দিষ্ট বিজ্ঞপ্তির আবেদন। কোনো শূন্যপদ আছে কি না জানতে চাইলে <a href="/professional-emails/job-inquiry-email-sample/">job inquiry email</a> আলাদা কাজ। নিচের নমুনার বন্ধনীর তথ্য এবং সংযুক্তির তালিকা নিজের বাস্তব তথ্য দিয়ে বদলান।</p>`,
samples:[{id:'job-email-fresher',title:'নমুনা ১: ফ্রেশারের বাংলা আবেদন ইমেইল',text:`নমুনা — বিজ্ঞপ্তি ও নিজের তথ্য অনুযায়ী সম্পাদনা করুন
Subject: [পদের নাম] পদে আবেদন — [আপনার নাম] — [Job ID থাকলে]

শ্রদ্ধেয় নিয়োগকারী,
[বিজ্ঞপ্তির উৎস ও তারিখ]-এ প্রকাশিত [পদের নাম] পদে আবেদন করছি। আমি [বিষয়]-এ [ডিগ্রি/প্রকৃত শিক্ষাগত যোগ্যতা] সম্পন্ন করেছি।

[কোর্স প্রকল্প/ইন্টার্নশিপ/প্রাসঙ্গিক কাজ]-এ [নিজের কাজের সংক্ষিপ্ত, যাচাইযোগ্য বিবরণ] করেছি। এই অভিজ্ঞতা বিজ্ঞপ্তিতে চাওয়া [প্রাসঙ্গিক দক্ষতা]-এর সঙ্গে সম্পর্কিত।

বিজ্ঞপ্তির নির্দেশনা অনুযায়ী আমার [CV এবং প্রকৃত সংযুক্তির নাম] সংযুক্ত করেছি। আমার যোগ্যতা বিবেচনা করে সাক্ষাৎকারের সুযোগ দিলে কৃতজ্ঞ থাকব।

ধন্যবাদান্তে,
[নাম]
[ফোন]
[ইমেইল]
সংযুক্তি: [বাস্তবে সংযুক্ত ফাইলের নাম]`},
{id:'job-email-experienced',title:'নমুনা ২: Experienced applicant email',text:`Illustrative draft — follow the vacancy instructions
Subject: Application for [position] — [name] — [job ID, if required]

Dear Hiring Team,
I am applying for the [position] advertised on [source and date]. My experience in [relevant function] includes [brief factual example of work relevant to this vacancy].

In my role as [actual role], I [specific responsibility or verified achievement]. This is relevant to your requirement for [skill/responsibility from the advertisement].

I have attached [CV and other documents actually requested and attached]. I would welcome the opportunity to discuss how my experience could contribute to [team/function].

Thank you for considering my application.
Kind regards,
[name]
[telephone]
[email]
Attachments: [actual filenames]`},
{id:'job-email-internship',title:'নমুনা ৩: Advertised internship application',text:`Illustrative draft — for an advertised internship
Subject: Application for [internship title] — [name] — [reference, if required]

Dear Hiring Team,
I am applying for the [internship title] announced on [source and date]. I am a [current year/programme or recent graduate] in [subject] at [institution].

Through [course project or relevant activity], I have practised [relevant skill] by [brief factual example]. I would like to develop this skill while contributing to [work described in the advertisement].

My availability is [truthful dates/schedule, if relevant]. I have attached [CV and other requested files actually attached]. Please let me know if you need further information.

Kind regards,
[name]
[telephone]
[email]
Attachments: [actual filenames]`}],
guide:`<h2>Subject কীভাবে লিখবেন?</h2><p>বিজ্ঞপ্তিতে নির্দিষ্ট subject, পদের নাম বা reference দেওয়া থাকলে হুবহু অনুসরণ করুন। অন্যথায় পদ ও নিজের নাম স্পষ্ট করুন। উদাহরণ: <strong>Application for Accounts Assistant — [Name]</strong>। নমুনার Job ID ঘর পূরণ করার তথ্য না থাকলে সেটি বাদ দিন; বানিয়ে লিখবেন না।</p><h2>ইমেইলের body ও cover letter কি একই?</h2><p>Body হলো ইমেইলের মূল বার্তা। বিজ্ঞপ্তিতে আলাদা cover letter চাওয়া হলে সেটি নির্দেশিত ফরম্যাটে সংযুক্ত করুন; শুধু body লিখে সংযুক্তি দেওয়া হয়েছে বলবেন না। আলাদা ফাইল না চাইলে প্রয়োজনের সঙ্গে মিলিয়ে সংক্ষিপ্ত পরিচয় দিন। একই দীর্ঘ চিঠি body ও attachment-এ অকারণে পুনরাবৃত্তি করার প্রয়োজন নেই। <a href="/cv-resume-templates/cover-letter-template-job-internship/">কভার লেটারের পূর্ণ নমুনা</a> দেখুন।</p><h2>CV পাঠানোর আগে চেকলিস্ট</h2><ol><li>বিজ্ঞপ্তির আসল উৎস, প্রাপকের ইমেইল, শেষ সময়, পদের নাম ও reference মিলিয়ে নিন। অনুমান করে ঠিকানা ব্যবহার করবেন না।</li><li>চাওয়া ফাইলের ধরন, সর্বোচ্চ আকার ও নামকরণের নিয়ম অনুসরণ করুন। PDF চাওয়া হলে DOCX পাঠাবেন না।</li><li>ফাইল খুলে সঠিক নাম, যোগাযোগ ও পদের তথ্য দেখুন। অন্য প্রতিষ্ঠানের পুরোনো নাম রয়ে গেছে কি না পরীক্ষা করুন।</li><li>Body-তে যেসব ফাইলের কথা লিখেছেন সেগুলো সত্যিই attach হয়েছে কি না দেখুন। পাসওয়ার্ড-সুরক্ষিত ফাইল পাঠানোর আগে গ্রহণকারীর নির্দেশনা দেখুন।</li><li>লিংক দিলে প্রয়োজনীয় অনুমোদিত access আছে কি না পরীক্ষা করুন। অপ্রয়োজনীয় NID, ব্যাংক তথ্য বা ব্যক্তিগত নথি যোগ করবেন না।</li></ol><h2>ফ্রেশার হলে অভিজ্ঞতার জায়গায় কী লিখবেন?</h2><p>প্রাসঙ্গিক কোর্স প্রকল্প, ইন্টার্নশিপ বা স্বেচ্ছাসেবী কাজের নিজের ভূমিকা লিখুন। চাকরির অভিজ্ঞতা নেই বলে বানানো প্রতিষ্ঠান, বছর বা ফলাফল যোগ করবেন না। <a href="/cv-resume-templates/fresher-cv-format-bangladesh-template/">ফ্রেশার CV গাইড</a> থেকে জীবনবৃত্তান্তের কাঠামো দেখুন।</p><h2>সাধারণ প্রশ্ন</h2><details><summary>সব জায়গায় ইংরেজিতে আবেদন করতে হবে?</summary><p>বিজ্ঞপ্তির ভাষা ও নির্দেশনা দেখুন। এখানে বাংলা ও ইংরেজি নমুনা আছে; কোনো নির্দিষ্ট ভাষা সব নিয়োগে বাধ্যতামূলক বলা হচ্ছে না।</p></details><details><summary>কেবল CV attach করে পাঠাব?</summary><p>নির্দেশনায় অন্য কিছু না থাকলে সংক্ষিপ্ত body-তে পদ, পরিচয় ও সংযুক্তি স্পষ্ট করা সহায়ক। নিয়োগকারীর নির্দিষ্ট প্রক্রিয়া অগ্রাধিকার পাবে।</p></details><details><summary>এই ফরম্যাট কি আবেদন গ্রহণ বা চাকরি নিশ্চিত করে?</summary><p>না। যোগ্যতা, বিজ্ঞপ্তির শর্ত ও নিয়োগকারীর মূল্যায়ন আলাদা বিষয়। এটি শুধু আবেদন গুছিয়ে লেখার সাধারণ সহায়তা।</p></details>`,
sources:`<p><a href="https://www.ejobs.com.bd/career-jobs/articlejob-application-email-bangla">eJobs-এর job application email বিষয়ক গাইড</a>-এও নির্দিষ্ট পদ, subject, body ও attachment আলাদা উপাদান হিসেবে আলোচনা করা হয়েছে। এটি প্রাসঙ্গিক লেখার নির্দেশিকা, কোনো নিয়োগকারীর বাধ্যতামূলক নিয়ম নয়। উপরের তিনটি নমুনা Bangla Format-এর নিজস্ব সাধারণ রচনা; কোনো চলমান চাকরির বিজ্ঞপ্তি নয়।</p>`,
related:`<a href="/professional-emails/email-subject-line-rules-examples/">Subject line লেখার নিয়ম</a> · <a href="/professional-emails/email-attachment-etiquette-naming-size/">ফাইল সংযুক্তির নিয়ম</a> · <a href="/professional-emails/job-inquiry-email-sample/">শূন্যপদের খোঁজ নেওয়ার ইমেইল</a>`
},{
route:'/office-letters-notices/salary-certificate-format/',category:'/office-letters-notices/',categoryName:'অফিস লেটার ও নোটিশ',title:'বেতন প্রত্যয়নপত্র: বাংলা-ইংরেজি নমুনা ও Word PDF | Bangla Format',h1:'বেতন প্রত্যয়নপত্র: বাংলা-ইংরেজি সনদ ও HR-এর কাছে আবেদন',description:'বেতন প্রত্যয়নপত্রের বাংলা ও ইংরেজি খসড়া, HR-এর কাছে আবেদন, মোট ও নিট বেতনের হিসাব এবং সম্পাদনাযোগ্য Word ও PDF নমুনা। নিয়োগকারীর যাচাই ও অনুমোদন প্রয়োজন।',lead:'নির্দিষ্ট মাস বা সময়কালের বেতনের তথ্য নিশ্চিত করার জন্য নিয়োগকারী প্রতিষ্ঠানের দুটি খসড়া এবং কর্মীর সনদ চাওয়ার আবেদন দেখুন। প্রকৃত সনদ অনুমোদিত কর্তৃপক্ষ ইস্যু করবে।',
intro:`<div class="callout callout-warning" role="note"><strong>খসড়া, ইস্যু করা সনদ নয়:</strong> বেতনের অঙ্ক ও সময়কাল payroll রেকর্ড থেকে যাচাই করে নিয়োগকারী প্রতিষ্ঠানের অনুমোদিত ব্যক্তি সনদ ইস্যু করবেন। এই সাধারণ নমুনা কোনো ব্যাংক, দূতাবাস বা অন্য সংস্থার গ্রহণযোগ্যতার নিশ্চয়তা দেয় না।</div><p>বেতন সনদে কোন মাস বা সময়কালের মূল বেতন, ভাতা, মোট, কর্তন ও নিট অঙ্ক দেওয়া হচ্ছে তা পরিষ্কার রাখুন। <a href="/office-letters-notices/employment-verification-letter/">কর্মরত থাকার প্রত্যয়নপত্র</a> শুধু কর্মসংস্থান নিশ্চিত করার আলাদা নথি।</p>`,
samples:[{id:'salary-certificate-bangla',title:'নমুনা ১: বাংলা বেতন প্রত্যয়নপত্র',text:`নমুনা খসড়া — নিয়োগকারী প্রতিষ্ঠানের যাচাই ও অনুমোদন প্রয়োজন
[প্রতিষ্ঠানের অনুমোদিত লেটারহেড]
রেফারেন্স: [প্রযোজ্য নম্বর]
ইস্যুর তারিখ: [তারিখ]

বেতন প্রত্যয়নপত্র

এই মর্মে প্রত্যয়ন করা যাচ্ছে যে, [কর্মীর নাম], কর্মী আইডি [প্রযোজ্য হলে], [প্রতিষ্ঠান]-এর [বিভাগ]-এ [পদবি] পদে কর্মরত আছেন।

বেতনের সময়কাল: [মাস ও বছর/সুনির্দিষ্ট সময়কাল]
মুদ্রা: বাংলাদেশি টাকা (BDT)
মূল বেতন: [অঙ্ক]
অন্তর্ভুক্ত ভাতা: [ধরন ও অঙ্ক]
মোট বেতন: [মূল বেতন ও অন্তর্ভুক্ত ভাতার যোগফল]
মোট কর্তন: [কর্তনের বিবরণ ও মোট অঙ্ক]
নিট প্রাপ্য: [মোট বেতন থেকে মোট কর্তন বাদ]
নিট প্রাপ্য কথায়: [একই অঙ্ক কথায়]

সনদ প্রদানের উদ্দেশ্য: [অনুমোদিত উদ্দেশ্য, প্রয়োজন হলে]।
উপরের তথ্য সংশ্লিষ্ট সময়কালের বেতন রেকর্ড অনুযায়ী প্রস্তুত করা হয়েছে।
তথ্য যাচাইয়ের যোগাযোগ: [অনুমোদিত প্রাতিষ্ঠানিক ইমেইল/ফোন]।

[অনুমোদিত স্বাক্ষরকারীর নাম ও পদবি]
[স্বাক্ষর ও প্রতিষ্ঠানের নিয়ম অনুযায়ী সিল]`},
{id:'salary-certificate-english',title:'নমুনা ২: English salary certificate',text:`Illustrative draft — employer verification and authorization required
[authorized organization letterhead]
Reference: [if applicable]
Issue date: [date]

Salary Certificate

This is to confirm that [employee name], employee ID [if applicable], is employed as [job title] in [department] at [organization].

Salary period: [month and year/specific period]
Currency: Bangladeshi Taka (BDT)
Basic salary: [amount]
Included allowances: [description and amounts]
Gross salary: [basic salary plus included allowances]
Total deductions: [description and total amount]
Net amount payable: [gross salary less total deductions]
Net amount in words: [same amount in words]

Purpose of issue: [authorized purpose, if required].
The figures above are prepared from the payroll records for the stated period.
For verification: [authorized institutional email/telephone].

[authorized signatory name and designation]
[signature and seal according to organizational procedure]`},
{id:'salary-certificate-request',title:'নমুনা ৩: HR-এর কাছে বেতন সনদের আবেদন',text:`নমুনা আবেদন — প্রকৃত তথ্য দিয়ে সম্পাদনা করুন
তারিখ: [তারিখ]
বরাবর: [HR/হিসাব বিভাগ/নির্ধারিত প্রাপকের পদবি]
[প্রতিষ্ঠানের নাম]
বিষয়: বেতন প্রত্যয়নপত্র প্রদানের আবেদন।

মহোদয়/মহোদয়া,
আমি [নাম], কর্মী আইডি [প্রযোজ্য হলে], [বিভাগ]-এ [পদবি] পদে কর্মরত। [প্রকৃত উদ্দেশ্য]-এর জন্য [মাস ও বছর/সময়কাল]-এর বেতনের তথ্যসংবলিত প্রত্যয়নপত্র প্রয়োজন।

সংশ্লিষ্ট রেকর্ড যাচাই করে সনদ ইস্যুর ব্যবস্থা এবং প্রয়োজনীয় প্রক্রিয়া জানালে কৃতজ্ঞ থাকব। গ্রহণকারী সংস্থার নির্ধারিত ফরম থাকলে তা সংযুক্ত করেছি [প্রযোজ্য না হলে বাক্যটি বাদ দিন]।

বিনীত,
[নাম ও পদবি]
[যোগাযোগ]
[স্বাক্ষর]
সংযুক্তি: [বাস্তবে সংযুক্ত নথি/প্রযোজ্য নয়]`}],
guide:`<h2>Word ও PDF নমুনা ডাউনলোড</h2><p>প্রতিটি Word ফাইল সম্পাদনাযোগ্য খসড়া; PDF ফাইল মুদ্রণ ও কাঠামো দেখার নমুনা, পূরণযোগ্য অনলাইন ফরম নয়। প্রকৃত অঙ্ক, সময়কাল ও অনুমোদন বসিয়ে প্রতিষ্ঠানকে দিয়ে নতুন সনদ ইস্যু করান।</p><ul><li>বাংলা সনদ: <a href="/assets/downloads/salary-certificate-bangla.docx" download>Word (.docx)</a> · <a href="/assets/downloads/salary-certificate-bangla.pdf" download>PDF</a></li><li>English certificate: <a href="/assets/downloads/salary-certificate-english.docx" download>Word (.docx)</a> · <a href="/assets/downloads/salary-certificate-english.pdf" download>PDF</a></li><li>সনদ চাওয়ার আবেদন: <a href="/assets/downloads/salary-certificate-request.docx" download>Word (.docx)</a> · <a href="/assets/downloads/salary-certificate-request.pdf" download>PDF</a></li></ul><h2>মোট ও নিট বেতনের পার্থক্য</h2><p>এই সাধারণ ছকে মোট বেতন = মূল বেতন + অন্তর্ভুক্ত ভাতা। নিট প্রাপ্য = মোট বেতন − মোট কর্তন। বাস্তব payroll-এ অন্য উপাদান থাকলে প্রতিষ্ঠানের হিসাব অনুযায়ী সেগুলো আলাদা করে দেখান। প্রাপ্য অঙ্ককে ব্যাংকে ইতিমধ্যে জমা হওয়া অর্থ বলে দাবি করবেন না।</p><p><strong>শুধু হিসাব বোঝানোর কাল্পনিক উদাহরণ:</strong> মূল বেতন ৩০,০০০ টাকা + অন্তর্ভুক্ত ভাতা ১০,০০০ টাকা = মোট ৪০,০০০ টাকা। মোট কর্তন ২,০০০ টাকা হলে নিট প্রাপ্য ৩৮,০০০ টাকা (আটত্রিশ হাজার টাকা)। এটি কোনো কর্মীর বেতন, অনুমোদিত বেতনস্কেল বা করের হিসাব নয়।</p><h2>বেতন সনদ, payslip ও অন্য সনদের পার্থক্য</h2><ul><li><strong>বেতন সনদ:</strong> নিয়োগকারী কর্তৃক নির্দিষ্ট সময়কালের বেতনের তথ্য নিশ্চিত করার নথি।</li><li><strong>Payslip:</strong> বেতন প্রক্রিয়ার বিস্তারিত বিবরণ থাকতে পারে; গ্রহণকারী আলাদা সনদ চাইলে একটিকে অন্যটির বিকল্প ধরে নেবেন না।</li><li><strong>অভিজ্ঞতা সনদ:</strong> কাজের সময়কাল ও দায়িত্বের রেকর্ড; এটি আয় যাচাইয়ের একই নথি নয়।</li><li><strong>আয় সনদ বা শেষ বেতন সনদ:</strong> আলাদা উদ্দেশ্য ও নির্ধারিত কর্তৃপক্ষ/ফরম থাকতে পারে। এই সাধারণ খসড়া সরকারি LPC/ELPC বা অন্য নির্ধারিত ফরমের বিকল্প নয়।</li></ul><h2>ইস্যুর আগে যাচাই</h2><ol><li>কর্মীর নাম, পদ, বিভাগ ও প্রযোজ্য আইডি প্রতিষ্ঠানের রেকর্ডের সঙ্গে মিলিয়ে নিন।</li><li>এক মাসের বেতন, বর্তমান মাসিক হার এবং বার্ষিক আয় গুলিয়ে ফেলবেন না; সময়কাল ও মুদ্রা লিখুন।</li><li>ভাতা ও কর্তন ঠিকভাবে অন্তর্ভুক্ত হয়েছে কি না এবং যোগ-বিয়োগ মেলে কি না পরীক্ষা করুন।</li><li>সংখ্যায় ও কথায় লেখা নিট অঙ্ক একই কি না দেখুন।</li><li>গ্রহণকারী সংস্থার নির্দিষ্ট শর্ত এবং অনুমোদিত স্বাক্ষরকারী যাচাই করুন। প্রয়োজন ছাড়া ব্যাংক হিসাব, NID বা ব্যক্তিগত ঠিকানা যোগ করবেন না।</li></ol><h2>সাধারণ প্রশ্ন</h2><details><summary>ব্যাংক বা ভিসার জন্য কি এই নমুনাই যথেষ্ট?</summary><p>গ্রহণকারী সংস্থার বর্তমান শর্ত দেখুন। তারা নিজস্ব ফরম, payslip বা অন্য প্রমাণ চাইতে পারে। এই নমুনার গ্রহণযোগ্যতার নিশ্চয়তা নেই।</p></details><details><summary>নিজে খসড়া করে জমা দেওয়া যাবে?</summary><p>খসড়া তৈরি করা যায়, কিন্তু প্রতিষ্ঠানের যাচাই, অনুমোদিত স্বাক্ষর ও ইস্যু ছাড়া সেটি নিয়োগকারীর সনদ নয়। সিল বা স্বাক্ষর নকল করবেন না।</p></details><details><summary>PDF-এ তথ্য পূরণ করা যাবে?</summary><p>এখানকার PDF সাধারণ মুদ্রণ নমুনা। সম্পাদনার জন্য Word ফাইল ব্যবহার করুন এবং ইস্যুর আগে সংশোধিত নথি নতুন করে পরীক্ষা করুন।</p></details>`,
sources:`<p><a href="https://old.sau.edu.bd/home/forms">শেরেবাংলা কৃষি বিশ্ববিদ্যালয়ের Forms তালিকায়</a> Salary Certificate Application Form আছে। এটি প্রতিষ্ঠানের নিজস্ব আবেদন প্রক্রিয়ার উদাহরণ; সব নিয়োগকারীর একই নিয়ম বা কোনো ব্যাংকের গ্রহণযোগ্যতা প্রমাণ করে না। উপরের তিনটি খসড়া Bangla Format-এর নিজস্ব রচনা, বিশ্ববিদ্যালয়ের অনুমোদিত ফরমের অনুলিপি নয়।</p>`,
related:`<a href="/office-letters-notices/employment-verification-letter/">কর্মরত থাকার প্রত্যয়নপত্র</a> · <a href="/office-letters-notices/experience-certificate-format/">অভিজ্ঞতা সনদ</a>`
}];

import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fonts,fontTotals} from './font-catalog.mjs';
const out='reports/font-expansion-2026-11-11',stage='tmp/font-research';
const read=async p=>JSON.parse(await fs.readFile(p,'utf8'));
const inspection=await read(stage+'/inspection.json'), register=await read('assets/fonts/font-source-register.json');
const originals=['tiro-bangla','baloo-da-2','atma','galada','mina','alkatra','purno','fiona-bangla','ekusher-alo','ekushey-kolom','ekushey-aloucik','ekushey-lekhani','ekushey-belycon','rupali','ekushey-sumon','ekushey-sumit','ekushey-sornaly','ekushey-shimanto','ekushey-sharifa','ekushey-saraswatii','ekushey-punarbhaba','ekushey-puja','ekushey-mukto','ekushey-mohua','ekushey-azad','ekushey-ananta','ekushey-amar-desh','ekushey-amar-bangla','ekushey-16-december','mukti'];
const reserves=['ekushey-godhuli','ekushey-durga','ekushey-lohit','sagar','mitra','bensen-handwriting'];
const labels={'purno':'Purno','fiona-bangla':'BL Fiona Bangla','ekushey-kolom':'Ekushey Bangla Kolom','sagar':'Sagar','mitra':'Mitra (Mitra Mono)','bensen-handwriting':'BenSen Handwriting'};
const candidateAudit=[];
for(const id of [...originals,...reserves]){
 const cleared=register.find(f=>f.slug===id||f.upstream===id);
 const row={candidate:cleared?.name||labels[id]||id.replaceAll('-',' '),selection:reserves.includes(id)?'reserve':'candidate',status:cleared?'CLEARED':'HELD — NOT RELEASED'};
 if(cleared){Object.assign(row,{source:cleared.source,version:cleared.version,license:cleared.licenseId,sha256:cleared.sha256,reason:'Publisher, embedded metadata, applicable license and source obligations verified.'});}
 else {
  row.reason=id==='purno'?'Official publisher permits free personal/commercial use but expressly prohibits modification, customization and redistribution. Package has no redistribution license.':id==='fiona-bangla'?'Publisher package metadata explicitly prohibits distribution/modification, conflicting with open-source publicity. No permission inferred from the blog.':id==='ekushey-sumon'?'Embedded notice only says GNU GPL, with no verified version, corresponding source or font embedding exception.':'GPL grant found, but matching preferred editable source and build materials were not verified in the inspected upstream sources. Held pending source verification; this is not a claim that redistribution is universally prohibited.';
  const record=inspection.find(f=>f.package===id+'.package');if(record)row.embeddedEvidence=record.fonts.map(f=>({file:f.file,names:f.names,embeddingFlags:f.fsType}));
  row.source=['sagar','bensen-handwriting'].includes(id)?'https://www.omicronlab.com/bangla-fonts.html':id==='purno'?'https://bangla.gov.bd/purno/':`https://ekushey.org/font/${id}/`;
 }
 candidateAudit.push(row);
}
const evidenceFiles=(await fs.readdir(stage)).filter(f=>/\.(?:html|json|package|ttf|otf|gz|txt)$/.test(f)&&!f.includes('inspection-summary')&&!f.includes('baseline-mobile'));
const evidence=[];for(const file of evidenceFiles){const b=await fs.readFile(stage+'/'+file);evidence.push({file,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex')});}
await fs.writeFile(out+'/candidate-audit.json',JSON.stringify({date:'2026-11-11',targetAdditions:30,verifiedAdditions:22,shortfall:8,candidates:candidateAudit,localResearchEvidence:evidence},null,2)+'\n');
await fs.copyFile(stage+'/baseline-mobile.json',out+'/baseline-mobile.json');
const perf=[];for(const file of ['baseline-mobile.json','hub-mobile-1.json','hub-mobile-2.json','hub-mobile-3.json','detail-mobile.json']){
 const r=await read(out+'/'+file), requests=r.audits['network-requests'].details.items;
 const previews=requests.filter(i=>i.url.includes('.preview.woff2'));
 perf.push({file,url:r.finalDisplayedUrl,score:Math.round(r.categories.performance.score*100),LCPms:r.audits['largest-contentful-paint'].numericValue,TBTms:r.audits['total-blocking-time'].numericValue,CLS:r.audits['cumulative-layout-shift'].numericValue,previewRequests:previews.map(i=>i.url.split('/').at(-1)),transferBytes:requests.reduce((s,i)=>s+(i.transferSize||0),0)});
 if(file.startsWith('hub-')&&previews.length)throw Error('Unopened hub preview downloaded during mobile audit');
}
const results={date:'2026-11-11',method:'Lighthouse 13.6.0 local mobile simulated throttling; Chrome headless; googlesyndication.com blocked to avoid advertising requests; GA4 remains enabled. Lab results, not field Core Web Vitals. Same blocking configuration before and after.',runs:perf};
await fs.writeFile(out+'/performance-results.json',JSON.stringify(results,null,2)+'\n');
await fs.writeFile('assets/fonts/font-performance-results.json',JSON.stringify(results,null,2)+'\n');
const validation=await read(out+'/font-validation.json');
const summary=`# Verified Bangla font expansion — 11 November 2026

Released locally: **22 additions, 29 distinct families, 26 local download packages**. The requested target was 30 additions / 37 families: **shortfall 8** after inspecting all 30 candidates and all six reserves. The shortfall was reported before release packaging. No unverified font was added to reach a count.

## Selection decisions

| Candidate | Status | Reason |
|---|---|---|
${candidateAudit.map(c=>`| ${c.candidate} | ${c.status} | ${c.reason} |`).join('\n')}

Purno's publisher expressly forbids redistribution: [official terms](https://bangla.gov.bd/purno/). BL Fiona's downloaded binaries prohibit redistribution; public open-source publicity does not resolve that conflict: [publisher package page](https://ekushey.org/font/fiona-bangla/). GPL holds are source-verification holds, not assertions that the fonts cannot ever be redistributed. The six reserves were examined in the specified order; only Ekushey Lohit and Mitra cleared. No families outside the approved lists were substituted.

## What is implemented

- Existing shared layout and routes preserved. 22 new detail pages include individual usage guidance, specimen strings, exact version/style/encoding, sources, checksums and download/license information.
- Search, type/download filtering and two-family comparison include all additions. Variable weights use actual per-file axis ranges. No synthetic bold for static files.
- Original selected binaries remain byte-for-byte unchanged in each ZIP, alongside license/attribution notices and applicable original ancillary material. Each GPL ZIP includes the matching source archive, SFD editable sources, build script and license. Only the selected regular/book/variable style is bundled; weights and italics are not extra families.
- OFL 1.0 preview derivatives are renamed internally with the BF Preview prefix; original downloads retain upstream names. Full cmap, glyph order, metrics, layout tables and variable axes survive WOFF2 conversion. No subsetting, including the Lohit no-subsetting binary.
- Totals derive from catalog data. Canonicals, breadcrumbs, hub ItemList, sitemap and llms references include actual released counts. Current AdSense publisher 5724834317757008 preserved; 404 stays ad-free.
- All 22 original binaries have distinct SHA-256 values and distinct decomposed Bengali outline/metric fingerprints. Kolom and Bangla Kolom publisher links contain identical packages and count once. Mitra Mono is presented under embedded family name Mitra. Mukti and Mukto remain distinct. Rupali and the existing related Siyam Rupali have distinct upstream family identities; no weight or encoding variant was added as a family.

## Compatibility limits

The core conjunct, vowel-sign and numeral specimens shape without .notdef in all 22 additions. Mixed Latin may fall back when absent, disclosed on detail pages. These automated specimens do not prove every Bengali sequence or every application renders correctly. Extended rare U+09E2 (ৢ) is missing in Ekusher Alo and is disclosed. Rupali has unusually large advances in bn_llikaar and bn_below_ba; original metrics are preserved and its detail page discloses the limitation. Archived fonts are labeled through source/evidence fields, without claiming measured popularity. No keyword search-volume estimate or ranking guarantee is inferred from publisher catalog inclusion.

## Measured performance

${results.method}

| Run | Score | LCP (ms) | TBT (ms) | CLS | Preview requests |
|---|---:|---:|---:|---:|---:|
${perf.map(r=>`| ${r.file} | ${r.score} | ${Math.round(r.LCPms)} | ${Math.round(r.TBTms)} | ${r.CLS.toFixed(4)} | ${r.previewRequests.length} |`).join('\n')}

All three expanded-hub mobile runs request **zero unopened preview fonts**. The detail page loads only its own Tiro preview. Shared text-font preloads remain exactly two. The larger HTML catalog adds content and the audit timings vary; no claim of an overall speed improvement is made. Font metadata and ZIP assets are downloaded only when requested. Tests are local, not production measurements.

## Validation

- PASS: release/SEO/AdSense/privacy/performance/content-preservation checks across 80 canonical pages plus 404; 3,878 local references, 78 valid schema blocks and zero fragment warnings.
- PASS: 127 local HTTP/MIME checks, including all 22 new pages, ZIPs and WOFF2 files, ads.txt, and missing URLs returning 404.
- PASS: fontTools + HarfBuzz validation of ${validation.additions} new binaries, archive CRC/content, SHA-256 values, notices, GPL source contents, cmap, glyph metrics, GSUB/GPOS, variable axes and Bengali specimens. Detailed results are in font-validation.json.
- PASS: browser search, empty results, 26-download filter, Baloo/Alkatra two-family comparison, real 700 weight and Tiro ZIP download. Mobile hub and detail page tested at 390×844; long source URL overflow fixed. Screenshot: mobile-library.png.
- PASS: clean-source build and tests without node_modules. GitHub Linux runner, actual AI Studio import and production settings were not executed or verified.

## Publication checklist

1. Review this **22-addition** release and the eight-family shortfall; do not advertise 37 families.
2. Use banglaformat-production.zip for static deployment; retain CNAME banglaformat.co and HTTPS. For source-based GitHub workflow use the project source, not the static ZIP as the source checkout.
3. Verify live hub totals 29 / 26, representative new detail pages and downloads, corrected privacy policy, new publisher 5724834317757008 only, ads.txt HTTP 200 text/plain and missing-page 404.
4. Keep supplied license notices, full fonts and source archives. Do not strip GPL source.tar.gz or rename original binaries while repackaging.
5. Live publishing and AdSense review submission remain separate user-controlled actions. No deployment or review submission was performed here.

The machine-readable source/license register is assets/fonts/font-source-register.json inside the deployment ZIP. Measured performance results are assets/fonts/font-performance-results.json. Per-file release checksums are release/manifest.json. Candidate audit and full lab reports are retained beside this review in reports/font-expansion-2026-11-11.
`;
await fs.writeFile(out+'/RELEASE-REVIEW.md',summary);
console.log('Recorded 36 candidate decisions, eight-family shortfall, sources, validation and five mobile lab runs.');

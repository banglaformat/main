import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const sha=s=>createHash('sha256').update(s).digest('hex');
const manifestPath='reports/content-implementation-2026-11-11/approved-changes.json';const manifest=JSON.parse(await readFile(manifestPath,'utf8'));
const ngo=`
      <!-- ngo-drafts:start -->
      <section class="prose" aria-labelledby="ngo-experience-certificate">
        <h2 id="ngo-experience-certificate">এনজিও অভিজ্ঞতা সনদপত্র: কাজের বিবরণ বসানোর উদাহরণ</h2>
        <p>এনজিওতে কাজের জন্য সাধারণ সনদের সঙ্গে প্রকল্প, ভূমিকা ও যাচাইকৃত দায়িত্বের বিবরণ প্রয়োজন অনুযায়ী যোগ করা যায়। নিচের দুটি বাক্যাংশ কেবল লেখার উদাহরণ; কোনো এনজিওর অনুমোদিত ফরম বা HR-পর্যালোচিত নথি নয়। সাধারণ সনদের প্রয়োজনীয় পরিচয়, সময়কাল ও স্বাক্ষরের অংশ বাদ দেবেন না।</p>
        <h3>মাঠপর্যায়ের কাজ: বাংলা বাক্যাংশ</h3>
        <p class="template-content" id="ngo-field-example">[কর্মীর নাম] [প্রতিষ্ঠানের নাম]-এ [যোগদানের তারিখ] থেকে [শেষ কর্মদিবস] পর্যন্ত [পদবি] হিসেবে কর্মরত ছিলেন। [প্রযোজ্য প্রকল্পের নাম]-এ তাঁর যাচাইকৃত দায়িত্ব ছিল [প্রকৃত দায়িত্বের সংক্ষিপ্ত বিবরণ]। প্রকল্পে কাজের সময়কাল [প্রযোজ্য সময়কাল]; এটি সম্পূর্ণ চাকরির মেয়াদের থেকে ভিন্ন হলে আলাদা করে উল্লেখ করা হলো।</p>
        <button type="button" class="btn btn-secondary" data-copy-target="ngo-field-example">বাংলা বাক্যাংশ কপি করুন</button>
        <h3>Programme support: English wording example</h3>
        <p class="template-content" id="ngo-programme-example" lang="en">[Employee name] was employed by [organization] as [job title] from [employment start date] to [employment end date]. Their verified responsibilities for [programme/project, if applicable] included [accurate responsibilities]. The programme assignment covered [assignment dates, if different from the employment period].</p>
        <button type="button" class="btn btn-secondary" data-copy-target="ngo-programme-example">ইংরেজি বাক্যাংশ কপি করুন</button>
        <p>নিজের নেই এমন দায়িত্ব, প্রকল্পের অর্থের পরিমাণ বা কর্মদক্ষতার মূল্যায়ন বসাবেন না। প্রকল্পের মেয়াদকে চাকরির মেয়াদ হিসেবে দেখাবেন না। প্রকৃত নিয়োগকারী ও স্বাক্ষর করার ক্ষমতা যাচাই করুন। কোনো নির্দিষ্ট এনজিওর নাম, লোগো বা সিল বসিয়ে অনুমোদিত সনদ বলে চালানো যাবে না।</p>
        <p>পূর্ণ খসড়ার জন্য <a href="#official-bangla-certificate">বাংলা সনদের নমুনা</a> বা <a href="#official-english-certificate">ইংরেজি সনদের নমুনা</a> ব্যবহার করুন; তথ্য প্রতিষ্ঠানকে যাচাই করতে হবে।</p>
      </section>
      <!-- ngo-drafts:end -->
`;
const cert='office-letters-notices/experience-certificate-format/index.html';let certHtml=await readFile(cert,'utf8');if(!certHtml.includes('<!-- ngo-drafts:start -->')){certHtml=certHtml.replace('</main>',ngo+'</main>');certHtml=certHtml.replace('<a class="btn btn-secondary" href="#verification-checklist">','<a class="btn btn-secondary" href="#ngo-experience-certificate">এনজিওর কাজের বিবরণ</a>\n          <a class="btn btn-secondary" href="#verification-checklist">');await writeFile(cert,certHtml);manifest.changes.find(c=>c.file===cert).afterSHA256=sha(certHtml);}
const tc='academic-applications/tc-abedon-transfer-certificate/index.html';let text=await readFile(tc,'utf8');if(!text.includes('id="tc-current-process"')){
 const before=text;await mkdir('reports/content-final-batch-2026-11-11',{recursive:true});const snapshot='reports/content-final-batch-2026-11-11/tc-before.html';await writeFile(snapshot,before);
 const answers=[
 'টিসি প্রস্তুত ও ইস্যু করার সময় প্রতিষ্ঠান, নথির অবস্থা এবং প্রযোজ্য অনুমোদনের ওপর নির্ভর করে। নির্দিষ্ট কর্মদিবসের নিশ্চয়তা না ধরে নিজের প্রতিষ্ঠানের দপ্তর থেকে সময় ও প্রয়োজনীয় ক্লিয়ারেন্স জেনে নিন।',
 'ফি আছে কি না, থাকলে কত এবং কোন মাধ্যমে জমা দিতে হবে—নিজের প্রতিষ্ঠান ও প্রযোজ্য বোর্ডের বর্তমান নির্দেশনা থেকে যাচাই করুন। পুরোনো ফরমের অঙ্ক বা অন্য প্রতিষ্ঠানের ফি নিজের ক্ষেত্রে প্রযোজ্য ধরে নেবেন না।',
 'প্রথমে ভর্তিচ্ছু প্রতিষ্ঠানে আসন, যোগ্যতা এবং প্রযোজ্য প্রক্রিয়া সম্পর্কে জেনে নিন। প্রতিষ্ঠান বা বোর্ডের যে অনুমোদন প্রয়োজন, তা অনুসরণ না করে শুধু টিসি নেওয়াকে ভর্তি নিশ্চিত হওয়ার প্রমাণ মনে করবেন না।',
 'বছরের মাঝামাঝি আবেদন গ্রহণ করা হবে কি না তা সংশ্লিষ্ট শ্রেণি, শিক্ষাবর্ষ, প্রতিষ্ঠান ও বোর্ডের বর্তমান নির্দেশনার ওপর নির্ভর করে। বদলি বা বাসস্থান পরিবর্তনের কারণ থাকলেও নির্ধারিত প্রক্রিয়া যাচাই করুন।',
 'প্রযোজ্য বোর্ডের বর্তমান নির্দেশনা অনুসরণ করুন। ঢাকা বোর্ডের e-TC পোর্টালে বর্তমান ও ভর্তিচ্ছু প্রতিষ্ঠানের সম্মতি, ফি-সংক্রান্ত বার্তা এবং এরপর বোর্ডের চূড়ান্ত অনুমোদনের ধাপ বর্ণিত আছে। শুধু ফি জমা দিলেই চূড়ান্ত অনুমোদন হয়েছে ধরে নেবেন না।',
 'আপনার জমা দেওয়া কোন মূল নথি বা কপি ফেরত নেওয়ার প্রয়োজন, তা প্রতিষ্ঠানের দপ্তরের সঙ্গে মিলিয়ে তালিকা করুন। নথি গ্রহণ বা ফেরত দেওয়ার সময় প্রাপ্তিস্বীকারের ব্যবস্থা সম্পর্কে জেনে নিন। সব প্রতিষ্ঠানের জন্য একই বাধ্যবাধকতা এই নমুনা থেকে ধরে নেবেন না।'
 ];let i=0;const replacements=[];text=text.replace(/<details class="faq-item"[\s\S]*?<\/details>/g,block=>{if(i>=answers.length)throw Error('Unexpected FAQ count');return block.replace(/<p>[\s\S]*?<\/p>/,p=>{const after='<p>'+answers[i++]+'</p>';replacements.push({before:p,after});return after;});});if(i!==6)throw Error('Expected six TC FAQs');
 const entry=`
      <!-- content-entry:start -->
      <section class="content-entry callout callout-info" aria-labelledby="tc-current-process"><h2 id="tc-current-process">টিসি চাওয়া আর নতুন প্রতিষ্ঠানে ভর্তি আলাদা কাজ</h2><p>এই পেজ বর্তমান প্রতিষ্ঠানের কাছে টিসি চাওয়ার জন্য। গ্রহণকারী প্রতিষ্ঠানের জন্য <a href="/academic-applications/admission-with-transfer-certificate/">টিসিসহ ভর্তির আবেদন ও নমুনা</a> দেখুন।</p><p>উৎস: <a href="https://erp.dhakaeducationboard.gov.bd/index.php/tc">ঢাকা বোর্ডের e-TC পোর্টালের নিয়মাবলি</a>, দেখা হয়েছে ১১ নভেম্বর ২০২৬। বর্তমান ফি, সময়সীমা ও নিজের শ্রেণি/শিক্ষাবর্ষের প্রযোজ্যতা সংশ্লিষ্ট বোর্ডের কাছে যাচাই করুন।</p></section>
      <!-- content-entry:end -->
`;
 text=text.replace('<article class="post-content">','<article class="post-content">'+entry).replace('আপডেট: ২০২৬','আপডেট: ১১ নভেম্বর ২০২৬').replace(/"dateModified":\s*"[^"]*"/g,'"dateModified": "2026-11-11"');await writeFile(tc,text);manifest.changes.push({file:tc,snapshot,beforeSHA256:sha(before),afterSHA256:sha(text),titleChanged:false,replacements});
}
await writeFile(manifestPath,JSON.stringify(manifest,null,2)+'\n');
let xml=await readFile('sitemap.xml','utf8');const loc='<loc>https://banglaformat.co/academic-applications/tc-abedon-transfer-certificate/</loc>';const i=xml.indexOf(loc),end=xml.indexOf('</url>',i);xml=xml.slice(0,i)+xml.slice(i,end).replace(/<lastmod>[^<]+<\/lastmod>/,'<lastmod>2026-11-11</lastmod>')+xml.slice(end);for(const p of ['sitemap.xml','public/sitemap.xml'])await writeFile(p,xml);
let llms=await readFile('llms.txt','utf8');if(!llms.includes('## Transfer admission and NGO examples'))llms+='\n## Transfer admission and NGO examples\n\n- [Admission using a transfer certificate](https://banglaformat.co/academic-applications/admission-with-transfer-certificate/): Receiving-institution application drafts; actual board/institution forms and approvals take priority. No universal fee or deadline.\n- [NGO experience wording](https://banglaformat.co/office-letters-notices/experience-certificate-format/#ngo-experience-certificate): Illustrative role/project wording inside the existing certificate guide, not an institution-approved or HR-reviewed template.\n';for(const p of ['llms.txt','public/llms.txt'])await writeFile(p,llms);
console.log('Added NGO wording to existing guide and corrected six unsupported TC FAQ answers.');

import {readFile,writeFile,readdir,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {optimizeTextFontLoading} from './font-loading.mjs';
const report='reports/performance-2026-11-11';await mkdir(report+'/before',{recursive:true});
const sha=b=>createHash('sha256').update(b).digest('hex');
let css=await readFile(report+'/google-fonts-variable.css','utf8');const upstream=[];
css=css.replace(/\/\* ([a-z-]+) \*\/\s*(@font-face\s*\{[\s\S]*?\})/g,(_,subset,block)=>{const file='noto-sans-bengali-web-'+subset+'.woff2',source=block.match(/url\(([^)]+)\)/)[1];upstream.push({file,source,subset});return block.replace(source,'/assets/fonts/'+file);});
for(const entry of upstream){const bytes=await readFile('assets/fonts/'+entry.file);if(bytes.subarray(0,4).toString()!=='wOF2')throw Error('Invalid WOFF2 '+entry.file);entry.bytes=bytes.length;entry.sha256=sha(bytes);entry.license='noto-sans-bengali-web-OFL.txt';}
await writeFile('assets/fonts/webfont-provenance.json',JSON.stringify({family:'Noto Sans Bengali',weights:'400 700',downloaded:'2026-11-11',sourceStylesheet:'https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400..700&display=swap',licenseSource:'https://raw.githubusercontent.com/google/fonts/main/ofl/notosansbengali/OFL.txt',files:upstream},null,2)+'\n');
const styleFile='assets/css/style.css',oldCss=await readFile(styleFile,'utf8');
if(!oldCss.includes('noto-sans-bengali-web-bengali.woff2')){await writeFile(report+'/before/style.css',oldCss);await writeFile(styleFile,css+'\n'+oldCss);}
const dirs=['about','academic-applications','bangla-fonts','contact','converters','cv-resume-templates','disclaimer','editorial-policy','office-letters-notices','privacy-policy','professional-emails','terms','guides'];
async function walk(d){let out=[];for(const e of await readdir(d,{withFileTypes:true})){const p=d+'/'+e.name;if(e.isDirectory())out.push(...await walk(p));else if(p.endsWith('.html'))out.push(p);}return out;}
const manifestFile='reports/final-audit-2026-11-11/changes.json',manifest=JSON.parse(await readFile(manifestFile,'utf8')),changes=[];
for(const file of ['index.html','404.html',...(await Promise.all(dirs.map(walk))).flat()]){const before=await readFile(file,'utf8'),after=optimizeTextFontLoading(before);if(after===before)continue;const snapshot=report+'/before/'+file.replaceAll('/','__');await writeFile(snapshot,before);changes.push({file,snapshot,beforeSHA256:sha(before),afterSHA256:sha(after),removedExternalFontStylesheets:(before.match(/href="https:\/\/fonts.googleapis.com/g)||[]).length});let entry=manifest.changes.find(c=>c.file===file);if(!entry){entry={file,snapshot,beforeSHA256:sha(before)};manifest.changes.push(entry);}entry.afterSHA256=sha(after);await writeFile(file,after);}
await writeFile(manifestFile,JSON.stringify(manifest,null,2)+'\n');await writeFile(report+'/changes.json',JSON.stringify(changes,null,2)+'\n');console.log(`Optimized font delivery on ${changes.length} pages; ${upstream.length} licensed local WOFF2 subsets.`);

// Shared by Vite previews and the static release builder.
export const navigation = [
  ['/', 'হোম'],
  ['/academic-applications/', 'আবেদনপত্র'],
  ['/office-letters-notices/', 'অফিস লেটার'],
  ['/professional-emails/', 'প্রফেশনাল ইমেইল'],
  ['/cv-resume-templates/', 'সিভি ও রেজুমে'],
  ['/bangla-fonts/', 'বাংলা ফন্ট'],
  ['/contact/', 'যোগাযোগ'],
];

export function normalizeNavigation(html, route) {
  route = route.split(/[?#]/)[0].replace(/index\.html$/, '');
  if (!route.endsWith('/') && !route.endsWith('.html')) route += '/';
  const current = href => route === href || (href !== '/' && route.startsWith(href));
  const link = ([href, label], mobile) => {
    const active = current(href);
    const aria = active ? ` aria-current="${route === href ? 'page' : 'location'}"` : '';
    return `<a href="${href}" class="${mobile ? 'mobile-nav-link' : 'nav-link'}${active ? ' active' : ''}"${aria}>${label}</a>`;
  };
  const mobileItems = [...navigation.slice(0, -1), ['/about/', 'আমাদের সম্পর্কে'], navigation.at(-1)];
  return html.replace(/<header class="site-header">[\s\S]*?<\/header>/, header => header
    .replace(/<nav class="desktop-nav"[^>]*>[\s\S]*?<\/nav>/,
      `<nav class="desktop-nav" aria-label="প্রধান নেভিগেশন">\n${navigation.map(item => '        ' + link(item, false)).join('\n')}\n      </nav>`)
    .replace(/<nav class="mobile-nav"[^>]*>[\s\S]*?<\/nav>/,
      `<nav class="mobile-nav" id="mobileNav" aria-label="মোবাইল নেভিগেশন">\n      <ul class="mobile-nav-list">\n${mobileItems.map(item => '        <li>' + link(item, true) + '</li>').join('\n')}\n      </ul>\n    </nav>`)
    .replace(/<button\b[^>]*\bid="mobileNavToggle"[^>]*>/,
      '<button type="button" class="nav-toggle-btn" id="mobileNavToggle" aria-label="মেনু খুলুন বা বন্ধ করুন" aria-controls="mobileNav" aria-expanded="false">'));
}

export const publisher='5724834317757008';
export const adsTxt=`google.com, pub-${publisher}, DIRECT, f08c47fec0942fa0\n`;
export function applyAdsense(html){
 // Remove any previous account and loader before installing exactly one current pair.
 html=html.replace(/<!--\s*Google AdSense\s*-->\s*/gi,'').replace(/<meta\b[^>]*name=["']google-adsense-account["'][^>]*>\s*/gi,'').replace(/<script\b[^>]*src=["'][^"']*(?:googlesyndication\.com|doubleclick\.net)[^"']*["'][^>]*>[\s\S]*?<\/script>\s*/gi,'');
 if(/name="robots"[^>]*content="[^"]*noindex/.test(html))return html;
 return html.replace('</head>',`<meta name="google-adsense-account" content="ca-pub-${publisher}">\n<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-${publisher}" crossorigin="anonymous"></script>\n</head>`);
}

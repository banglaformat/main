import {readFile} from 'node:fs/promises';
import {textFontPreloads} from './font-loading.mjs';
import {applyAdsense} from './adsense-config.mjs';
// Reuse existing site HTML, rather than maintaining another brand/navigation design.
const reference=await readFile(new URL('../about/index.html',import.meta.url),'utf8');
let header=reference.match(/<header class="site-header">[\s\S]*?<\/header>/)[0].replaceAll('mobile-nav-link active','mobile-nav-link');
header=header.replace('<a href="/contact/" class="nav-link">','<a href="/bangla-fonts/" class="nav-link">বাংলা ফন্ট</a>\n        <a href="/contact/" class="nav-link">');
header=header.replace('<li><a href="/about/"','<li><a href="/bangla-fonts/" class="mobile-nav-link">বাংলা ফন্ট</a></li>\n        <li><a href="/about/"');
let footer=reference.match(/<footer class="site-footer">[\s\S]*?<\/footer>/)[0];
footer=footer.replace('<li><a href="/cv-resume-templates/">সিভি ও রেজুমে</a></li>','<li><a href="/cv-resume-templates/">সিভি ও রেজুমে</a></li>\n            <li><a href="/bangla-fonts/">বাংলা ফন্ট</a></li>\n            <li><a href="/guides/install-bangla-font/">ফন্ট ইনস্টল গাইড</a></li>');
const backToTop=reference.match(/<button type="button" class="back-to-top"[\s\S]*?<\/button>/)[0];
const fontCss=textFontPreloads;
export function applySiteShell(html,route){
 let sharedHeader=header;
 if(route.startsWith('/bangla-fonts/'))sharedHeader=sharedHeader.replace('href="/bangla-fonts/" class="nav-link"','href="/bangla-fonts/" class="nav-link active" aria-current="page"');
 html=html.replace(/<header class="font-header">[\s\S]*?<\/header>/,sharedHeader).replace(/<footer class="font-footer">[\s\S]*?<\/footer>/,backToTop+'\n'+footer);
 html=html.replace('<link rel="stylesheet" href="/assets/css/font-library.css">',`${fontCss}\n<link rel="stylesheet" href="/assets/css/style.css">\n<link rel="stylesheet" href="/assets/css/font-library.css">`);
 html=html.replace('<meta name="theme-color" content="#0a4936">','<meta name="theme-color" content="#15803d">');
 html=html.replace('https://banglaformat.co/assets/images/font-library-social.svg','https://banglaformat.co/assets/images/logo.png');
 html=html.replace('</head>',`<meta property="og:site_name" content="Bangla Format"><meta name="msapplication-TileColor" content="#15803d"><link rel="manifest" href="/site.webmanifest"></head>`);
 html=html.replace('</body>','<script src="/assets/js/main.js" defer></script></body>');
 // Stable site-wide entity identifiers connect the new topic to the existing publisher.
 html=html.replaceAll('"publisher":{"@type":"Organization","name":"Bangla Format","url":"https://banglaformat.co/"}','"publisher":{"@type":"Organization","@id":"https://banglaformat.co/#organization","name":"Bangla Format","url":"https://banglaformat.co/"}');
 return applyAdsense(html);
}


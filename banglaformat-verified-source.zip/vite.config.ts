import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';
import fs from 'node:fs';
import {defineConfig, Plugin, UserConfig} from 'vite';
import {normalizeNavigation} from './scripts/site-navigation.mjs';

// Match the static release routes; never scan or serve research/source backups.
const pageDirs = ['about', 'academic-applications', 'bangla-fonts', 'contact',
  'converters', 'cv-resume-templates', 'disclaimer', 'editorial-policy',
  'office-letters-notices', 'privacy-policy', 'professional-emails', 'terms', 'guides'];
const rootFiles = ['index.html', '404.html', 'ads.txt', 'robots.txt', 'sitemap.xml',
  'site.webmanifest', 'llms.txt'];

function custom404Plugin(): Plugin {
  return {
    name: 'static-route-handler',
    transformIndexHtml(html, context) {
      return normalizeNavigation(html, context.path);
    },
    configureServer(server) {
      const root = path.resolve(server.config.root);
      server.middlewares.use((req, res, next) => {
        const [rawPath, query] = (req.url || '/').split(/\?(.*)/s);
        const notFound = () => {
          res.statusCode = 404;
          res.setHeader('Content-Type', 'text/html; charset=utf-8');
          res.end(req.method === 'HEAD' ? undefined : normalizeNavigation(fs.readFileSync(path.join(root, '404.html'), 'utf8'), '/404.html'));
        };
        let url: string;
        try { url = decodeURIComponent(rawPath); } catch { return notFound(); }
        // Only the runtime endpoints actually used by these static pages.
        if (url === '/@vite/client' || url === '/@react-refresh') return next();
        const parts = url.split('/');
        if (url.includes('\\') || url.includes('\0') || parts.some(p => p === '..' || p.startsWith('.'))) return notFound();
        const allowed = url === '/' || rootFiles.includes(url.slice(1)) ||
          /^\/favicon[^/]*\.(png|svg|ico)$/.test(url) ||
          parts[1] === 'assets' || pageDirs.includes(parts[1]);
        if (!allowed) return notFound();
        let file = path.resolve(root, '.' + url);
        if (file !== root && !file.startsWith(root + path.sep)) return notFound();
        try {
          if (fs.statSync(file).isDirectory()) {
            file = path.join(file, 'index.html');
            if (!fs.statSync(file).isFile()) return notFound();
            if (!url.endsWith('/')) {
              res.writeHead(301, {Location: rawPath + '/' + (query === undefined ? '' : '?' + query)});
              return res.end();
            }
          }
          if (!fs.statSync(file).isFile()) return notFound();
        } catch { return notFound(); }
        next();
      });
    },
  };
}

function getHtmlInputs(): Record<string, string> {
  const inputs: Record<string, string> = {};
  function scan(dir: string) {
    for (const entry of fs.readdirSync(dir, {withFileTypes: true})) {
      const file = path.join(dir, entry.name);
      if (entry.isDirectory()) scan(file);
      else if (entry.isFile() && entry.name.endsWith('.html')) inputs[file.replaceAll(path.sep, '_')] = path.resolve(file);
    }
  }
  for (const dir of pageDirs) scan(dir);
  for (const file of ['index.html', '404.html']) inputs[file] = path.resolve(file);
  return inputs;
}

export default defineConfig((): UserConfig => ({
  appType: 'mpa',
  // Root assets are authoritative, as in scripts/build-static.mjs.
  publicDir: false,
  plugins: [react(), tailwindcss(), custom404Plugin()],
  resolve: {alias: {'@': path.resolve(process.cwd(), '.')}},
  build: {rollupOptions: {input: getHtmlInputs()}},
  server: {
    hmr: process.env.DISABLE_HMR !== 'true',
    watch: process.env.DISABLE_HMR === 'true' ? null : {},
  },
}));

/* BanglaFormat independent Bijoy/SutonnyMJ legacy text conversion engine.
 * No third-party code or font binaries included. Legacy encodings are ambiguous;
 * inspect results, especially mixed Latin and uncommon conjuncts.
 */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.BanglaFormatBijoy=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){'use strict';
const pairs=[
['Av','আ'],['A','অ'],['B','ই'],['C','ঈ'],['D','উ'],['E','ঊ'],['F','ঋ'],['G','এ'],['H','ঐ'],['I','ও'],['J','ঔ'],
...Array.from('KLMNOPQRSTUVWXYZ_`abcdefghijklmnopqrst').map((x,i)=>[x,Array.from('কখগঘঙচছজঝঞটঠডঢণতথদধনপফবভমযরলশষসহড়ঢ়য়ৎংঃ')[i]]),
['u','ঁ'],['v','া'],['w','ি'],['x','ী'],['y','ু'],['z','ু'],['~','ূ'],['ƒ','ূ'],['„','ৃ'],['†','ে'],['‡','ে'],['ˆ','ৈ'],['‰','ৈ'],['Š','ৗ'],['|','।'],['&','্‌'],
['^','্ব'],['‘','্তু'],['’','্থ'],['‹','্ক'],['Œ','্ক্র'],['”','চ্'],['—','্ত'],['˜','দ্'],['™','দ্'],['š','ন্'],['›','ন্'],['œ','্ন'],['Ÿ','্ব'],['¡','্ব'],['¢','্ভ'],['£','্ভ্র'],['¤','ম্'],['¥','্ম'],['¦','্ব'],['§','্ম'],['¨','্য'],['©','র্'],['ª','্র'],['«','্র'],['¬','্ল'],['­','্ল'],['®','ষ্'],['¯','স্'],
...Array.from('°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏ').map((x,i)=>[x,['ক্ক','ক্ট','ক্ষ্ণ','ক্ত','ক্ম','ক্র','ক্ষ','ক্স','গু','জ্ঞ','গ্দ','গ্ধ','ঙ্ক','ঙ্গ','জ্জ','্ত্র','জ্ঝ','জ্ঞ','ঞ্চ','ঞ্ছ','ঞ্জ','ঞ্ঝ','ট্ট','ড্ড','ণ্ট','ণ্ঠ','ণ্ড','ত্ত','ত্থ','ত্ম','ত্র','দ্দ'][i]]),
...Array.from('×ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþ').map((x,i)=>[x,['দ্ধ','দ্ব','দ্ম','ন্ঠ','ন্ড','ন্ধ','ন্স','প্ট','প্ত','প্প','প্স','ব্জ','ব্দ','ব্ধ','ভ্র','ম্ন','ম্ফ','্ন','ল্ক','ল্গ','ল্ট','ল্ড','ল্প','ল্ফ','শু','শ্চ','শ্ছ','ষ্ণ','ষ্ট','ষ্ঠ','ষ্ফ','স্খ','স্ট','স্ন','স্ফ','্প','হু','হৃ','হ্ন','হ্ম'][i]]),
['iæ','রু'],['ÿ','ক্ষ'],['Mø','গ্ল'],['cø','প্ল'],['eø','ব্ল'],['kø','শ্ল']
];
const map=new Map(pairs); for(let i=0;i<10;i++)map.set(String(i),'০১২৩৪৫৬৭৮৯'[i]);
const legacyTokens=[...map.keys()].sort((a,b)=>b.length-a.length);
const cons=/[ক-হড়ঢ়য়ৎ]/u;const isCons=c=>!!c&&cons.test(c);const sign=/[ািীুূৃেৈোৌঁ]/u;
const pre=new Set(['ি','ে','ৈ']);
function glyphDecode(src){let out='';for(let i=0;i<src.length;){let match=legacyTokens.find(k=>src.startsWith(k,i));if(match){out+=map.get(match);i+=match.length;}else{out+=src[i++];}}return out;}
function reorderDecoded(src){let a=Array.from(src);for(let i=0;i<a.length;i++){
// Legacy pre-base vowel appears before entire consonant cluster.
if(pre.has(a[i])){let j=i+1;if(!isCons(a[j]))continue;j++;while(a[j]==='্'&&isCons(a[j+1]))j+=2;const mark=a.splice(i,1)[0];a.splice(j-1,0,mark);i=j-1;}
}
// Legacy reph is written after its base cluster. Move it before the cluster.
for(let i=0;i<a.length-1;i++){if(a[i]!=='র'||a[i+1]!=='্')continue;let end=i;let j=i-1;while(j>=0&&sign.test(a[j]))j--;if(!isCons(a[j]))continue;let start=j;while(start>=2&&a[start-1]==='্'&&isCons(a[start-2]))start-=2;if(start===0||a[start-1]!=='্'){a.splice(i,2);a.splice(start,0,'র','্');i=start+1;}}
return a.join('').replace(/ো/g,'ো').replace(/ৌ/g,'ৌ').replace(/অা/g,'আ').replace(/্্/g,'্').normalize('NFC');}
function bijoyToUnicode(src){if(typeof src!=='string')throw new TypeError('Expected text');return src.split(/(\r\n|\n|\r)/).map(s=>reorderDecoded(glyphDecode(s))).join('');}
// Encode Unicode clusters in legacy visual order. Use the shortest reversible glyph for conjuncts.
const preferred=new Map();for(const [legacy,unicode] of map){if(!preferred.has(unicode)||legacy.length<preferred.get(unicode).length)preferred.set(unicode,legacy);}
for(const [u,b] of [['র্','©'],['ে','†'],['ৈ','ˆ'],['ি','w'],['ু','y'],['ূ','~'],['্র','ª'],['্য','¨'],['ক্ষ','¶'],['জ্ঞ','¹'],['ং','s'],['ঃ','t'],['ঁ','u']])preferred.set(u,b);
const unicodeTokens=[...preferred.keys()].filter(x=>x!=='র্').sort((a,b)=>b.length-a.length);
function encodeCluster(text){let s=text.normalize('NFC').replace(/য়/g,'য়').replace(/ড়/g,'ড়').replace(/ঢ়/g,'ঢ়').replace(/ো/g,'ো').replace(/ৌ/g,'ৌ');let a=Array.from(s);let result='';for(let i=0;i<a.length;){
let prefix='';if(a[i]==='র'&&a[i+1]==='্'&&isCons(a[i+2])){prefix='©';i+=2;}
let base='';let k=i;while(k<a.length){const t=unicodeTokens.find(t=>a.slice(k,k+Array.from(t).length).join('')===t);if(!t)break;if(pre.has(t)||t==='া'||t==='ৗ'||t==='ী'||t==='ু'||t==='ূ'||t==='ৃ'||t==='ঁ'){break;}base+=preferred.get(t);k+=Array.from(t).length;if(a[k]==='্'&&isCons(a[k+1]))continue;break;}
if(!base){const t=unicodeTokens.find(t=>a.slice(i,i+Array.from(t).length).join('')===t);if(t){result+=preferred.get(t);i+=Array.from(t).length;}else{result+=a[i++];}continue;}
i=k;let vowel='';if(pre.has(a[i])){vowel=a[i++];}else if(a[i]==='ে'&&(a[i+1]==='া'||a[i+1]==='ৗ')){vowel=a[i]==='ে'?'ে':'';}
let suffix='';while(i<a.length&&(/[ািীুূৃৗঁ]/u.test(a[i]))){suffix+=preferred.get(a[i])??a[i];i++;}
result+=(vowel?preferred.get(vowel):'')+base+prefix+suffix;
}return result;}
function unicodeToBijoy(src){if(typeof src!=='string')throw new TypeError('Expected text');return src.split(/(\r\n|\n|\r|[ \t]+)/).map(s=>encodeCluster(s)).join('');}
function diagnose(src,direction){const hasBangla=/[\u0980-\u09ff]/u.test(src);const highLegacy=/[\u0080-\u00ff\u2018-\u201e\u2020-\u203a]/u.test(src);const ascii=/[A-Za-z]/.test(src);const warnings=[];if(direction==='bijoy'&&hasBangla)warnings.push('ইনপুটে Unicode বাংলা আছে; এটি আবার Bijoy হিসেবে রূপান্তর করবেন না।');if(direction==='bijoy'&&ascii)warnings.push('সাধারণ ইংরেজি ও Bijoy ANSI টেক্সট আলাদা করা সবসময় সম্ভব নয়; ফল যাচাই করুন।');if(direction==='unicode'&&/[\u200c\u200d]/u.test(src))warnings.push('ZWJ/ZWNJ এবং বিরল যুক্তাক্ষর পুরোনো ANSI ফন্টে একইভাবে নাও থাকতে পারে।');return warnings;}
return Object.freeze({bijoyToUnicode,unicodeToBijoy,diagnose,mappingCount:map.size});
});

# Complete the remaining five internal font downloads

## Install from verified upstream sources

Run `python scripts/install-pending-fonts.py` on a computer with internet access. It installs Hind Siliguri Regular and Anek Bangla Variable from the official Google Fonts repository, alongside their OFL license text, after validating the font file signature and license content. Check that the script reports both as installed. These binaries are **not already in this ZIP**.

## Kalpurush

Author repository: https://github.com/potasiyam/Kalpurush

Download the original release font and the accompanying `LICENSE` from that repository. The repository's LICENSE declares SIL OFL 1.1. Inspect font metadata and place the font and its original license in `assets/fonts/` before enabling an internal download link.

## Siyam Rupali and SolaimanLipi

Source references: https://github.com/subrata6630/Bangla-Web-Fonts and https://github.com/wpexpertinbd/bangla-keyboard/tree/main/macos/fonts-licenses

The licensing statements across distributions are inconsistent (Siyam Rupali GPL vs. SolaimanLipi GPL/OFL). Obtain the exact original font binaries with their matching distribution licenses and retain the full copyright/attribution text. Do not label these OFL without file-specific evidence. Do not redistribute proprietary ANSI font variants.

## Before enabling links

For each file: confirm actual family via font metadata, verify binary signature, retain the corresponding license and copyright notice, record its SHA-256 and upstream revision, test Bangla glyph shaping, then add a local `/assets/fonts/<verified filename>` download link and matching `@font-face` rule. No substitute fonts are permitted. Avoid claiming that pending fonts are installed until all these checks pass.

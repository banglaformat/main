Self-hosted downloadable fonts:
Noto Sans Bengali Regular (TTF) — SIL OFL 1.1
Noto Serif Bengali Regular (TTF) — SIL OFL 1.1
Source: system package fonts-noto-core, license file included.

Also bundled from the official Google Fonts repository:
Hind Siliguri Regular — SIL OFL 1.1, hind-siliguri-OFL.txt
Anek Bangla Variable — SIL OFL 1.1, anek-bangla-OFL.txt
See upstream-provenance.json for source URLs and SHA-256 hashes.
All four download ZIPs include the corresponding font and license notice.

Not bundled (publisher links and optional installed-font previews only):
Kalpurush, Siyam Rupali, SolaimanLipi.
Do not relabel substitutes as the original fonts.

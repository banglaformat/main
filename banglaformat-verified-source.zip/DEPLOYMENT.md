# Current production deployment

This static release contains 80 canonical pages, 29 font families and 26 local downloads. The approved font audit cleared 22 additions; eight additions remain unverified and excluded. Preserve publisher 5724834317757008, the current ads.txt authorization, and the ad-free noindex 404 page.

Use Node 24 or newer. Build and release checks need no dependency installation or API key:

    npm run check:release
    node scripts/package-release.mjs
    npm run preview

Only dist/ is deployable. The production ZIP contains those same files at its root. release/manifest.json records archive and individual-file SHA-256 values. Never publish the source root, public research uploads, report fixtures or development dependencies.

## GitHub Pages

Production repository: https://github.com/banglaformat/main. Select GitHub Actions as the Pages source. Keep custom domain banglaformat.co and Enforce HTTPS. Do not change DNS for this release.

The included .github/workflows/pages.yml validates pull requests. Run Validate and publish static site manually on main to build, test, upload only dist/ and deploy through the github-pages environment. Ordinary source pushes do not publish using this workflow. Observe successful Actions completion and live checks before treating a release as published.

Retain a recoverable previous commit/build. Do not bypass a failed check. Roll back by deploying the previous verified commit, preserving the domain and routes.

## Maintenance

npm run generate:fonts regenerates catalog pages and sitemap/llms references. Catalog data is in scripts/font-catalog.mjs and scripts/font-additions.json. Preserve shared layouts, existing routes and original document samples. Totals derive from catalog data.

New font binaries, versions, authors, sources, obligations and checksums are recorded in assets/fonts/font-source-register.json. Keep license notices and GPL source.tar.gz archives inside download packages. OFL 1.0 preview derivatives have renamed internal family names; original downloads remain unchanged. Do not replace font files without re-verification. Archived font limitations are disclosed on detail pages.

GitHub Pages does not apply _headers as custom HTTP response headers.

## Live checks

- Verify homepage, existing articles, all new font pages, navigation, copying, converter and downloads over HTTPS.
- Verify canonicals, breadcrumbs/schema, sitemap and robots/llms references retain banglaformat.co and existing paths.
- Verify hub totals 29 families / 26 downloads, not the unfulfilled 37-family target.
- Verify only publisher 5724834317757008, corrected privacy policy, ads.txt HTTP 200 text/plain with the current authorization, and ad-free 404.
- Confirm real missing URLs return 404 and research/source fixture URLs are unavailable.
- Compare deployed files with release/manifest.json; record cache delays or differences.

AdSense account configuration, consent messaging and review submission remain user-controlled. Passing technical tests does not guarantee indexing, rankings or AdSense approval.
